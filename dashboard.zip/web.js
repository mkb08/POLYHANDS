import { Engine, DATA_SAVER } from "./engine/engine.js";
import { applySetting, configView } from "./engine/settings.js";

const $ = (id) => document.getElementById(id);
const engine = new Engine();
const money = (x) => Number.isFinite(x) ? `$${x.toFixed(2)}` : "—";
const pct = (x) => Number.isFinite(x) ? `${x.toFixed(1)}%` : "—";
const cents = (x) => Number.isFinite(x) ? `${(x * 100).toFixed(1)}¢` : "—";
const esc = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const WALLETCONNECT_PROJECT_KEY = "polyscan.walletConnect.projectId";
const POLYMARKET_ADDRESS_KEY = "polyscan.walletConnect.accountAddress";
const savedDataSaver = localStorage.getItem("polyscan.web.dataSaver");
$("data-saver").checked = savedDataSaver == null ? true : savedDataSaver === "true";
$("wc-project-id").value = localStorage.getItem(WALLETCONNECT_PROJECT_KEY) || "";
$("poly-account-address").value = localStorage.getItem(POLYMARKET_ADDRESS_KEY) || "";
let renderTimer = null;
let lastState = null;
let walletProvider = null;
let connectedWallet = "";
let livePositions = [];
let walletSessionStatus = "Wallet not connected.";

function table(headers, rows, empty) {
  if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<table><thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table>`;
}

function statusText(state) {
  if (!state.running) return "Stopped. Start the engine to connect to public feeds.";
  const feeds = Object.entries(state.sources || {}).map(([name, value]) => `${name}: ${value}`).join(" · ");
  return `Running for ${Math.floor(state.uptime_s / 60)}m ${state.uptime_s % 60}s${feeds ? ` · ${feeds}` : ""}`;
}

function renderSettings() {
  $("settings").innerHTML = configView(engine).map((group) => `
    <div class="setting-group"><strong>${esc(group.title)}</strong>
      ${group.fields.map((field) => {
        if (field.type === "bool") return `<div class="setting"><label class="checkline"><input type="checkbox" data-setting="${esc(field.key)}" ${field.value ? "checked" : ""}>${esc(field.label)}</label><div class="small">${esc(field.help)}</div></div>`;
        if (field.type === "toggles") return `<div class="setting"><label>${esc(field.label)}</label>${field.options.map(([key, title]) => `<label class="checkline"><input type="checkbox" data-setting="${esc(field.key)}" data-toggle="${esc(key)}" ${field.value[key] ? "checked" : ""}>${esc(title)}</label>`).join("")}<div class="small">${esc(field.help)}</div></div>`;
        if (field.type === "select") return `<div class="setting"><label>${esc(field.label)}</label><select data-setting="${esc(field.key)}">${field.options.map(([value, title]) => `<option value="${esc(value)}" ${value === field.value ? "selected" : ""}>${esc(title)}</option>`).join("")}</select><div class="small">${esc(field.help)}</div></div>`;
        return `<div class="setting"><label>${esc(field.label)}</label><input type="number" data-setting="${esc(field.key)}" value="${esc(field.value)}" min="${field.min}" max="${field.max}" step="${field.step}"><div class="small">${esc(field.help)}</div></div>`;
      }).join("")}
    </div>`).join("");
}

function renderLiveAccount() {
  $("wallet-status").textContent = walletSessionStatus;
  $("disconnect-wallet").disabled = !walletProvider;
  $("connected-address").textContent = connectedWallet ? `Connected signer: ${connectedWallet}` : "";
  const markedValue = livePositions.reduce((sum, position) => sum + (Number(position.current_value) || 0), 0);
  const unrealized = livePositions.reduce((sum, position) => sum + (Number(position.unrealized_pnl) || 0), 0);
  const pnlClass = (n) => n > 0 ? "positive" : n < 0 ? "negative" : "";
  $("live-account-summary").innerHTML = [
    ["Open / redeemable positions", String(livePositions.length)],
    ["Marked position value", money(markedValue)],
    ["Unrealized P&L", `<span class="${pnlClass(unrealized)}">${money(unrealized)}</span>`],
  ].map(([label, value]) => `<div class="stat"><span>${esc(label)}</span><strong>${value}</strong></div>`).join("");
  const rows = livePositions.map((position) => `<tr>
    <td>${esc(position.title)}<div class="small">${esc(position.status)}${position.redeemable ? " · redeemable" : ""}</div></td>
    <td>${esc(position.outcome)}</td>
    <td>${Number(position.current_size).toFixed(2)}</td>
    <td>${money(Number(position.current_value))}</td>
    <td class="${pnlClass(Number(position.unrealized_pnl))}">${money(Number(position.unrealized_pnl))}</td>
  </tr>`);
  $("live-positions").innerHTML = table(
    ["Market", "Outcome", "Shares", "Marked value", "Unrealized P&L"],
    rows,
    "No open or redeemable positions found for this address."
  );
}

function isWalletAddress(value) {
  return /^0x[a-fA-F0-9]{40}$/.test(value);
}

function setConnectedWallet(address) {
  const previous = connectedWallet;
  connectedWallet = address;
  if (!isWalletAddress($("poly-account-address").value.trim())
      || $("poly-account-address").value.trim().toLowerCase() === previous.toLowerCase()) {
    $("poly-account-address").value = address;
    localStorage.setItem(POLYMARKET_ADDRESS_KEY, address);
  }
  walletSessionStatus = "Wallet connected (read-only; no signatures requested).";
  renderLiveAccount();
}

async function connectWallet() {
  $("wallet-error").textContent = "";
  const projectId = $("wc-project-id").value.trim();
  if (!projectId) throw new Error("Enter a WalletConnect project ID first. It is an app identifier, not a wallet key.");
  localStorage.setItem(WALLETCONNECT_PROJECT_KEY, projectId);

  const walletConnect = await import("https://esm.sh/@walletconnect/ethereum-provider@2.26.0?bundle");
  const EthereumProvider = walletConnect.EthereumProvider || walletConnect.default;
  if (!EthereumProvider || typeof EthereumProvider.init !== "function") {
    throw new Error("WalletConnect provider did not load correctly.");
  }
  const provider = await EthereumProvider.init({
    projectId,
    chains: [137],
    showQrModal: true,
    metadata: {
      name: "Polyscan Hands Paper Dashboard",
      description: "Read-only Polymarket account viewer",
      url: location.origin,
      icons: [],
    },
  });
  walletProvider = provider;
  provider.on("accountsChanged", (accounts) => {
    const address = Array.isArray(accounts) && typeof accounts[0] === "string" ? accounts[0] : "";
    if (address) setConnectedWallet(address);
    else {
      connectedWallet = "";
      walletSessionStatus = "Wallet disconnected.";
      renderLiveAccount();
    }
  });
  provider.on("disconnect", () => {
    walletProvider = null;
    connectedWallet = "";
    walletSessionStatus = "Wallet disconnected.";
    renderLiveAccount();
  });
  walletSessionStatus = "Waiting for wallet connection…";
  renderLiveAccount();
  try {
    await provider.connect();
    const accounts = await provider.request({ method: "eth_accounts" });
    const address = Array.isArray(accounts) && typeof accounts[0] === "string" ? accounts[0] : "";
    if (!isWalletAddress(address)) throw new Error("The wallet did not return a valid account address.");
    setConnectedWallet(address);
  } catch (error) {
    if (walletProvider === provider) walletProvider = null;
    connectedWallet = "";
    walletSessionStatus = "Wallet not connected.";
    try {
      await provider.disconnect();
    } catch (disconnectError) {
      console.error("WalletConnect cleanup failed", disconnectError);
    }
    renderLiveAccount();
    throw error;
  }
}

async function loadLivePositions() {
  $("wallet-error").textContent = "";
  const address = $("poly-account-address").value.trim();
  if (!isWalletAddress(address)) throw new Error("Enter a valid Polymarket account or proxy-wallet address.");
  localStorage.setItem(POLYMARKET_ADDRESS_KEY, address);
  livePositions = [];
  walletSessionStatus = "Loading public account positions…";
  renderLiveAccount();

  const positions = [];
  let cursor = null;
  for (let pageNumber = 0; pageNumber < 50; pageNumber++) {
    const url = new URL("https://data-api.polymarket.com/v2/positions");
    url.searchParams.set("user", address);
    url.searchParams.set("status", "OPEN");
    url.searchParams.set("filter_type", "TOKENS");
    url.searchParams.set("filter_amount", "0");
    url.searchParams.set("limit", "1000");
    url.searchParams.set("sort_by", "CURRENT_VALUE");
    url.searchParams.set("sort_direction", "DESC");
    if (cursor) url.searchParams.set("cursor", cursor);
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error(`Polymarket positions request failed (HTTP ${response.status}).`);
    const result = await response.json();
    if (!result || !Array.isArray(result.data) || !result.pagination) {
      throw new Error("Polymarket returned an unexpected positions response.");
    }
    positions.push(...result.data);
    cursor = result.pagination.next_cursor;
    if (!cursor) break;
    if (pageNumber === 49) throw new Error("Account has too many position pages to load safely.");
  }
  livePositions = positions;
  walletSessionStatus = `Loaded ${positions.length} public position${positions.length === 1 ? "" : "s"} for ${address}.`;
  renderLiveAccount();
}

function render(state = engine.state()) {
  lastState = state;
  const p = state.paper;
  $("status").textContent = statusText(state);
  $("start").disabled = state.running;
  $("stop").disabled = !state.running;

  const stats = [
    ["Equity", money(p.equity)], ["Paper P&L", money(p.pnl_usd)], ["Cash", money(p.cash)],
    ["Open positions", String(p.positions.length)], ["Markets", String(state.stats.markets)],
    ["Feeds", Object.keys(state.sources || {}).length ? "Connected" : "Waiting"],
  ];
  $("stats").innerHTML = stats.map(([label, value]) => `<div class="stat"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`).join("");

  const pnlClass = (n) => n > 0 ? "positive" : n < 0 ? "negative" : "";
  const positionRows = p.positions.map((pos) => `<tr>
    <td>${esc(pos.question)}<div class="small">${esc(pos.outcome)} · ${pos.shares.toFixed(2)} shares</div></td>
    <td>${money(pos.cost)}</td><td>${money(pos.value)}<div class="${pnlClass(pos.pnl_usd)}">${money(pos.pnl_usd)}</div></td>
    <td>${cents(pos.bid)}</td><td class="actions"><button data-action="sell" data-market="${esc(pos.marketId)}" data-side="${pos.side}" ${!state.running || !pos.tradable ? "disabled" : ""}>Paper sell</button></td>
  </tr>`);
  $("account").innerHTML = `<div class="stats">
    <div class="stat"><span>Start balance</span><strong>${money(p.start_usd)}</strong></div>
    <div class="stat"><span>Realized</span><strong class="${pnlClass(p.totals.realized)}">${money(p.totals.realized)}</strong></div>
    <div class="stat"><span>Fees</span><strong>${money(p.totals.fees)}</strong></div>
  </div>${table(["Position", "Cost", "Value / P&L", "Bid", "Action"], positionRows, "No open paper positions.")}`;

  const closingRows = (state.closing?.rows || []).map((row) => `<tr>
    <td>${esc(row.label)}</td><td>${row.ends_in_s == null ? "—" : `${row.ends_in_s.toFixed(1)}s`}</td>
    <td>${row.spot == null ? "—" : row.spot.toLocaleString()}</td><td>${row.p_up == null ? "—" : pct(row.p_up * 100)}</td>
    <td>${esc(row.status || "—")}</td>
  </tr>`);
  $("closing").innerHTML = table(["Coin", "Time left", "Spot", "Model Up chance", "Engine status"], closingRows, "Waiting for market data.");

  const candidateRows = state.candidates.map((market) => `<tr>
    <td>${esc(market.question)}<div class="small">${esc(market.event || market.coin || "")}</div></td>
    <td>${esc(market.outcome || "—")}<div class="small">Ask ${cents(market.ask)}</div></td>
    <td>${market.edge == null ? "—" : cents(market.edge)}<div class="small">${market.buy_votes}/25 BUY votes</div></td>
    <td class="actions"><button data-action="buy" data-market="${esc(market.id)}" data-side="${market.side}" ${!state.running || !market.has_book || market.pending0 || market.pending1 ? "disabled" : ""}>Paper buy</button></td>
  </tr>`);
  $("candidates").innerHTML = table(["Market", "Candidate", "Edge", "Action"], candidateRows, "No candidates yet. Wait for the engine to fetch markets.");

  const activityRows = p.trades.slice(0, 30).map((trade) => `<tr>
    <td>${new Date(trade.t).toLocaleTimeString()}</td><td>${esc(trade.side || "—")}</td>
    <td>${esc(trade.question || "—")}<div class="small">${esc(trade.outcome || "")}</div></td>
    <td>${esc(trade.status || "—")}</td><td>${esc(trade.reason || "")}</td>
    <td class="${pnlClass(trade.pnl)}">${trade.pnl == null ? "—" : money(trade.pnl)}</td>
  </tr>`);
  $("activity").innerHTML = table(["Time", "Action", "Market", "Result", "Details", "P&L"], activityRows, "No paper activity yet.");
}

function scheduleRender() {
  if (renderTimer != null) return;
  renderTimer = setTimeout(() => {
    renderTimer = null;
    render();
  }, 400);
}

engine.onChange = scheduleRender;
renderSettings();
render();
renderLiveAccount();
setInterval(scheduleRender, 1000);

$("start").addEventListener("click", () => {
  $("error").textContent = "";
  try {
    engine.setDataSaver($("data-saver").checked);
    engine.start();
    render();
  } catch (error) {
    $("error").textContent = `Could not start the paper engine: ${error.message || error}`;
  }
});

$("stop").addEventListener("click", () => {
  engine.stop();
  render();
});

$("data-saver").addEventListener("change", (event) => {
  localStorage.setItem("polyscan.web.dataSaver", String(event.target.checked));
  if (engine.running) $("status").textContent = "Data saver setting saved; stop and start to apply it.";
});

$("settings").addEventListener("change", (event) => {
  const input = event.target;
  const key = input.dataset.setting;
  if (!key) return;
  const raw = input.dataset.toggle
    ? { [input.dataset.toggle]: input.checked }
    : input.type === "checkbox" ? input.checked
      : input.type === "number" ? input.value : input.value;
  const result = applySetting(engine, key, raw);
  if (!result.ok) {
    $("error").textContent = result.message;
    return;
  }
  $("error").textContent = result.message || "";
  renderSettings();
  render();
});

$("wc-project-id").addEventListener("change", (event) => {
  localStorage.setItem(WALLETCONNECT_PROJECT_KEY, event.target.value.trim());
});

$("poly-account-address").addEventListener("change", (event) => {
  const value = event.target.value.trim();
  if (value) localStorage.setItem(POLYMARKET_ADDRESS_KEY, value);
});

$("connect-wallet").addEventListener("click", async () => {
  try {
    await connectWallet();
  } catch (error) {
    walletSessionStatus = "Wallet not connected.";
    $("wallet-error").textContent = `Wallet connection failed: ${error.message || error}`;
    renderLiveAccount();
  }
});

$("disconnect-wallet").addEventListener("click", async () => {
  if (!walletProvider) return;
  try {
    await walletProvider.disconnect();
    walletProvider = null;
    connectedWallet = "";
    walletSessionStatus = "Wallet disconnected.";
    renderLiveAccount();
  } catch (error) {
    $("wallet-error").textContent = `Could not disconnect wallet: ${error.message || error}`;
  }
});

$("load-positions").addEventListener("click", async () => {
  try {
    await loadLivePositions();
  } catch (error) {
    livePositions = [];
    walletSessionStatus = "Could not load public positions.";
    $("wallet-error").textContent = `Account data unavailable: ${error.message || error}`;
    renderLiveAccount();
  }
});

document.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button || !engine.running) return;
  $("error").textContent = "";
  const marketId = button.dataset.market;
  const side = Number(button.dataset.side);
  if (!marketId || !Number.isInteger(side)) return;
  if (button.dataset.action === "buy") engine.paperBuy(marketId, side);
  else if (button.dataset.action === "sell") engine.paperSell(marketId, side);
  scheduleRender();
});

window.addEventListener("beforeunload", () => engine.stop());
