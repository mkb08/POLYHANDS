import { Engine, DATA_SAVER } from "./engine/engine.js";
import { applySetting, configView } from "./engine/settings.js";

const $ = (id) => document.getElementById(id);
const engine = new Engine();
const money = (x) => Number.isFinite(x) ? `$${x.toFixed(2)}` : "—";
const pct = (x) => Number.isFinite(x) ? `${x.toFixed(1)}%` : "—";
const cents = (x) => Number.isFinite(x) ? `${(x * 100).toFixed(1)}¢` : "—";
const esc = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const savedDataSaver = localStorage.getItem("polyscan.web.dataSaver");
$("data-saver").checked = savedDataSaver == null ? true : savedDataSaver === "true";
let renderTimer = null;
let lastState = null;

function table(headers, rows, empty) {
  if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<table><thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table>`;
}

function statusText(state) {
  if (!state.running) return "Stopped. Start the engine to connect to public feeds.";
  const feeds = Object.entries(state.sources || {}).map(([name, value]) => `${name}: ${value}`).join(" · ");
  return `Running for ${Math.floor(state.uptime_s / 60)}m ${state.uptime_s % 60}s${feeds ? ` · ${feeds}` : ""}`;
}

function renderSettings() {
  $("settings").innerHTML = configView(engine).map((group) => `
    <div class="setting-group"><strong>${esc(group.title)}</strong>
      ${group.fields.map((field) => {
        if (field.type === "bool") return `<div class="setting"><label class="checkline"><input type="checkbox" data-setting="${esc(field.key)}" ${field.value ? "checked" : ""}>${esc(field.label)}</label><div class="small">${esc(field.help)}</div></div>`;
        if (field.type === "toggles") return `<div class="setting"><label>${esc(field.label)}</label>${field.options.map(([key, title]) => `<label class="checkline"><input type="checkbox" data-setting="${esc(field.key)}" data-toggle="${esc(key)}" ${field.value[key] ? "checked" : ""}>${esc(title)}</label>`).join("")}<div class="small">${esc(field.help)}</div></div>`;
        if (field.type === "select") return `<div class="setting"><label>${esc(field.label)}</label><select data-setting="${esc(field.key)}">${field.options.map(([value, title]) => `<option value="${esc(value)}" ${value === field.value ? "selected" : ""}>${esc(title)}</option>`).join("")}</select><div class="small">${esc(field.help)}</div></div>`;
        return `<div class="setting"><label>${esc(field.label)}</label><input type="number" data-setting="${esc(field.key)}" value="${esc(field.value)}" min="${field.min}" max="${field.max}" step="${field.step}"><div class="small">${esc(field.help)}</div></div>`;
      }).join("")}
    </div>`).join("");
}

function render(state = engine.state()) {
  lastState = state;
  const p = state.paper;
  $("status").textContent = statusText(state);
  $("start").disabled = state.running;
  $("stop").disabled = !state.running;

  const stats = [
    ["Equity", money(p.equity)], ["Paper P&L", money(p.pnl_usd)], ["Cash", money(p.cash)],
    ["Open positions", String(p.positions.length)], ["Markets", String(state.stats.markets)],
    ["Feeds", Object.keys(state.sources || {}).length ? "Connected" : "Waiting"],
  ];
  $("stats").innerHTML = stats.map(([label, value]) => `<div class="stat"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`).join("");

  const pnlClass = (n) => n > 0 ? "positive" : n < 0 ? "negative" : "";
  const positionRows = p.positions.map((pos) => `<tr>
    <td>${esc(pos.question)}<div class="small">${esc(pos.outcome)} · ${pos.shares.toFixed(2)} shares</div></td>
    <td>${money(pos.cost)}</td><td>${money(pos.value)}<div class="${pnlClass(pos.pnl_usd)}">${money(pos.pnl_usd)}</div></td>
    <td>${cents(pos.bid)}</td><td class="actions"><button data-action="sell" data-market="${esc(pos.marketId)}" data-side="${pos.side}" ${!state.running || !pos.tradable ? "disabled" : ""}>Paper sell</button></td>
  </tr>`);
  $("account").innerHTML = `<div class="stats">
    <div class="stat"><span>Start balance</span><strong>${money(p.start_usd)}</strong></div>
    <div class="stat"><span>Realized</span><strong class="${pnlClass(p.totals.realized)}">${money(p.totals.realized)}</strong></div>
    <div class="stat"><span>Fees</span><strong>${money(p.totals.fees)}</strong></div>
  </div>${table(["Position", "Cost", "Value / P&L", "Bid", "Action"], positionRows, "No open paper positions.")}`;

  const closingRows = (state.closing?.rows || []).map((row) => `<tr>
    <td>${esc(row.label)}</td><td>${row.ends_in_s == null ? "—" : `${row.ends_in_s.toFixed(1)}s`}</td>
    <td>${row.spot == null ? "—" : row.spot.toLocaleString()}</td><td>${row.p_up == null ? "—" : pct(row.p_up * 100)}</td>
    <td>${esc(row.status || "—")}</td>
  </tr>`);
  $("closing").innerHTML = table(["Coin", "Time left", "Spot", "Model Up chance", "Engine status"], closingRows, "Waiting for market data.");

  const candidateRows = state.candidates.map((market) => `<tr>
    <td>${esc(market.question)}<div class="small">${esc(market.event || market.coin || "")}</div></td>
    <td>${esc(market.outcome || "—")}<div class="small">Ask ${cents(market.ask)}</div></td>
    <td>${market.edge == null ? "—" : cents(market.edge)}<div class="small">${market.buy_votes}/25 BUY votes</div></td>
    <td class="actions"><button data-action="buy" data-market="${esc(market.id)}" data-side="${market.side}" ${!state.running || !market.has_book || market.pending0 || market.pending1 ? "disabled" : ""}>Paper buy</button></td>
  </tr>`);
  $("candidates").innerHTML = table(["Market", "Candidate", "Edge", "Action"], candidateRows, "No candidates yet. Wait for the engine to fetch markets.");

  const activityRows = p.trades.slice(0, 30).map((trade) => `<tr>
    <td>${new Date(trade.t).toLocaleTimeString()}</td><td>${esc(trade.side || "—")}</td>
    <td>${esc(trade.question || "—")}<div class="small">${esc(trade.outcome || "")}</div></td>
    <td>${esc(trade.status || "—")}</td><td>${esc(trade.reason || "")}</td>
    <td class="${pnlClass(trade.pnl)}">${trade.pnl == null ? "—" : money(trade.pnl)}</td>
  </tr>`);
  $("activity").innerHTML = table(["Time", "Action", "Market", "Result", "Details", "P&L"], activityRows, "No paper activity yet.");
}

function scheduleRender() {
  if (renderTimer != null) return;
  renderTimer = setTimeout(() => {
    renderTimer = null;
    render();
  }, 400);
}

engine.onChange = scheduleRender;
renderSettings();
render();
setInterval(scheduleRender, 1000);

$("start").addEventListener("click", () => {
  $("error").textContent = "";
  try {
    engine.setDataSaver($("data-saver").checked);
    engine.start();
    render();
  } catch (error) {
    $("error").textContent = `Could not start the paper engine: ${error.message || error}`;
  }
});

$("stop").addEventListener("click", () => {
  engine.stop();
  render();
});

$("data-saver").addEventListener("change", (event) => {
  localStorage.setItem("polyscan.web.dataSaver", String(event.target.checked));
  if (engine.running) $("status").textContent = "Data saver setting saved; stop and start to apply it.";
});

$("settings").addEventListener("change", (event) => {
  const input = event.target;
  const key = input.dataset.setting;
  if (!key) return;
  const raw = input.dataset.toggle
    ? { [input.dataset.toggle]: input.checked }
    : input.type === "checkbox" ? input.checked
      : input.type === "number" ? input.value : input.value;
  const result = applySetting(engine, key, raw);
  if (!result.ok) {
    $("error").textContent = result.message;
    return;
  }
  $("error").textContent = result.message || "";
  renderSettings();
  render();
});

document.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button || !engine.running) return;
  $("error").textContent = "";
  const marketId = button.dataset.market;
  const side = Number(button.dataset.side);
  if (!marketId || !Number.isInteger(side)) return;
  if (button.dataset.action === "buy") engine.paperBuy(marketId, side);
  else if (button.dataset.action === "sell") engine.paperSell(marketId, side);
  scheduleRender();
});

window.addEventListener("beforeunload", () => engine.stop());
