// The demo account: paper trading on real Polymarket order books.
//
// A position is a number of shares of one outcome token. It is bought by walking the real ask ladder and paying
// Polymarket's taker fee. Unlike a memecoin, a prediction market resolves definitively: at resolution each share of
// the winning outcome pays exactly $1 and each losing share pays $0, with no fee. So a signal's result is a fact,
// not an estimate, which gives a genuinely measured track record. Positions are normally held to resolution; the
// account can also exit early by selling into the bid (paying the taker fee again).
//
// The simulation leans conservative where paper trading usually flatters itself:
//   - Every order waits `latencyMs` before it meets the book, then fills only at prices within `maxSlippage` of the
//     quote it was sent at (a limit order). If the book moved away in the meantime, the order misses.
//   - Nothing is bought once a market is past its end time or has stopped accepting orders. A pre-close exit is
//     attempted in the last `exitBeforeEndMs` (0 = off) while the window is open.
//   - Selling is possible for as long as the exchange accepts orders, which on Polymarket lasts past the end of the
//     window until the result is settled. Measured on the five-minute crypto markets: from the end until at least a
//     minute later, buyers wait on the winning side at 99.9¢, while the losing side has none. With `afterEnd: "sell"`
//     a position whose market has ended is sold to those buyers at once instead of waiting for the result (a losing
//     side has nobody to sell to and waits; it pays $0 either way). polymarket.com hides its trade panel once a
//     market ends, so such a sale cannot go through the hands: it is an order sent straight to the exchange.
//   - Open positions are valued at what selling them into the bid ladder would return after the taker fee.
//
// For an arbitrage signal the account sends one order per outcome in the set. They are separate orders, as on the
// real venue: if every leg fills, the set is guaranteed to return exactly $1 per set at resolution; if some legs
// miss, the legs that filled are kept as ordinary, unhedged positions (leg risk).
//
// Strict mode (on by default) adds the frictions a browser-side paper account cannot observe directly, as explicit
// assumptions rather than measurements:
//   - Latency varies: 50%–150% of `latencyMs`, plus an occasional congestion spike of up to `spikeMs`.
//   - Other traders compete for the same liquidity: only `fillShare` of each visible level is available to us.
//   - Risk-free sets are the most contested trade on the venue: each arbitrage leg is independently lost to a faster
//     trader with probability `arbLegMissChance`.
//   - The venue occasionally rejects an order (`rejectChance`), and an order never fills against a book that has not
//     been confirmed within `maxBookAgeMs`.
//   - Winnings are credited `settleDelayMs` after resolution is seen (redemption), so cash stays locked meanwhile.
//
// Take profit and stop loss: any position that can be sold may carry a target price (`setTakeProfit`) and a stop price
// (`setStopLoss`), set by hand or armed on every new position from `autoTpPct` / `autoSlPct`. As soon as the best bid
// reaches the target, or falls to the stop, on the very price update that shows it, the whole position is sold the
// ordinary way (`sellAll`: latency, limit at the bid − maxSlippage, strict frictions, hands). If that order misses,
// the exit stays armed and is tried again while the price is still there. It only fires while the exchange takes
// orders and someone is bidding; a complete risk-free set is held to its $1 payout and takes neither.
//
// Known order constraints are checked against the current CLOB book: supported market version, fresh tick size,
// minimum size, negative-risk flag, and market status. Prices are tick-aligned and fees are rounded to five decimals.
// The fill-and-kill and competition behavior is still simulated. This cannot verify collateral allowance, account
// eligibility, or whether a real order would match. With `realAccount` on, the extension's `realGate` adds checks for
// visible login, geo-block, and cash state; it cannot verify every account-specific restriction or approval.
// Each market window is traded at most once by the engine: after a position there is closed, the next trade waits
// for a fresh signal in a later window.
//
// Hands (optional): `this.hands` is an async function that walks the order through a real trading screen first, the
// way a person would (the Polyscan Hands browser extension). It answers { ok, reason, id, ms, ui } once the order is
// ready to submit; it never submits anything. The order then leaves at the price showing at that moment, so the time
// the screen takes is paid for in price, as it would be with real money.

import { cents, feeForFill, feePerShare, usd, walkAsks, walkAsksShares, walkBids } from "./core.js";

export const START_USD = 10;
export const DEFAULT_SETTINGS = {
  autoTrade: true,
  sizePct: 10,
  stakeUsd: 0,          // fixed stake per trade in dollars (0 = off: sizePct of the starting balance)
  realAccount: false,   // also require your real Polymarket account to be able to place each order (extension only)
  maxPositions: 3,
  arbMaxUsd: 8,         // cap per risk-free set purchase
  aggressive: false,    // explore qualified five-minute crypto picks in the paper account (off: strict signals only)
  holdToResolution: true,
  latencyMs: 500,       // simulated time from decision to the order reaching the book
  maxSlippage: 0.01,    // limit = quoted price ± this; levels beyond it are not filled
  sizeHeadroom: 0.03,   // a minimum-size stake is sized for the 5 shares at the ask + this, so a small rise before the
                        // order goes in does not leave it under Polymarket's 5-share minimum (it would be refused)
  exitBeforeEndMs: 0,    // try to sell this long before the market's end (0 = off: entries are held to the close)
  afterEnd: "sell",     // once a market's window has ended: "sell" to the buyers still on the book, or "wait" for the result
  autoTpPct: 0,         // take profit armed on every new position at this % profit after fees (0 = off)
  autoSlPct: 0,         // stop loss armed on every new position at this % loss after fees (0 = off)
  strict: true,         // apply the frictions below
  latencyJitter: 0.5,   // latency drawn from latencyMs * (1 ± this)
  spikeChance: 0.1,     // chance an order hits a congestion spike
  spikeMs: 3000,        // extra delay of a spike: up to this much
  fillShare: 0.5,       // share of each visible book level we actually get
  arbLegMissChance: 0.25, // chance each arbitrage leg is taken by a faster trader
  rejectChance: 0.02,   // chance the venue rejects an order outright
  maxBookAgeMs: 45000,  // never fill against a book older than this
  settleDelayMs: 60000, // time from resolution to winnings landing in cash
  strategy_version: 7,
};

export const TP_RETRY_MS = 2000; // after a take-profit or stop-loss sell misses, wait this long before trying again
export const TP_PRESETS = [10, 25, 50]; // % profit after fees offered as one-tap targets
export const SL_PRESETS = [10, 25, 50]; // % loss after fees offered as one-tap stops
export const END_SELL_RETRY_MS = 3000;  // after an after-the-end sale misses, wait this long before trying again

function storageGet(key) { try { return JSON.parse(localStorage.getItem(key) || "null"); } catch { return null; } }
function storageSet(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* ignore */ } }
const realSleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// How the hands' refusal reads in the log: about your own account (only with `realAccount` on) or about the order.
const refusal = (r) => r.account ? "not executable on your real account" : "Polymarket would not take this order";
const floorToTick = (price, tick) => Math.floor((price + 1e-10) / tick) * tick;
const ceilToTick = (price, tick) => Math.ceil((price - 1e-10) / tick) * tick;

export class PaperAccount {
  constructor({ nowMs = () => Date.now(), getMarket = () => null, client = null, storageKey = "polyscan.paper", sleep = realSleep, random = Math.random } = {}) {
    this.nowMs = nowMs;
    this.getMarket = getMarket;
    this.client = client;
    this.storageKey = storageKey;
    this.sleep = sleep;
    this.random = random;
    this.pending = new Set();
    this.epoch = 0; // bumped on reset; an order still travelling from before a reset is dropped
    this.hands = null;
    this.realGate = null;
    this.load();
  }

  load() {
    const s = storageGet(this.storageKey);
    this.settings = { ...DEFAULT_SETTINGS, ...(s && s.settings) };
    const version = s?.settings ? s.settings.strategy_version || 0 : 0;
    const migrateSettings = version < 7;
    if (version < 5) this.settings.sizePct = 10;
    // v6: exploratory buys (negative estimated edge) are off; only trades that pass the signal bar are taken.
    if (version < 6) this.settings.aggressive = false;
    // v7: entries are made in the last seconds before the close and held to it: no early exit before the end.
    if (version < 7) this.settings.exitBeforeEndMs = 0;
    this.settings.strategy_version = 7;
    this.acct = s && s.acct ? s.acct : {
      createdAt: this.nowMs(), startUsd: START_USD, cash: START_USD,
      positions: {}, trades: [], totals: { fees: 0, realized: 0, invested: 0 },
    };
    this.acct.windows ||= {}; // marketId -> end time of a window the engine has already traded
    if (migrateSettings) this.save();
  }
  save() { storageSet(this.storageKey, { acct: this.acct, settings: this.settings }); }
  setSettings(patch) { Object.assign(this.settings, patch); this.save(); }
  // Start again with an empty account, keeping the settings; `startUsd` (if given, $1 or more) becomes the new
  // starting balance.
  reset(startUsd = null) {
    const keep = this.settings ? { ...this.settings } : null;
    this.epoch++; this.pending.clear(); localStorage.removeItem(this.storageKey); this.load();
    if (keep) this.settings = keep;
    const v = Number(startUsd);
    if (startUsd != null && Number.isFinite(v) && v >= 1) { this.acct.startUsd = v; this.acct.cash = v; }
    this.save();
  }

  // The stake the settings ask for, before Polymarket's minimum and the cash on hand: the fixed stake if one is set,
  // otherwise a share of the starting balance.
  stakeWanted() {
    const s = this.settings;
    return s.stakeUsd > 0 ? s.stakeUsd : this.acct.startUsd * s.sizePct / 100;
  }
  tradeUsd(m = null, side = 0) {
    const target = Math.min(this.acct.cash, this.stakeWanted());
    const ask = m && m.ask(side);
    if (!ask || ask <= 0) return target;
    const minShares = this.minShares(m, side);
    const minNotional = minShares * (Math.min(0.99, ask + (this.settings.sizeHeadroom || 0)) + feePerShare(m, ask));
    return Math.min(this.acct.cash, Math.max(target, minNotional));
  }
  freeCash() { return this.acct.cash; }
  log(e) { this.acct.trades.unshift({ t: this.nowMs(), ...e }); if (this.acct.trades.length > 200) this.acct.trades.length = 200; }
  posKey(marketId, side) { return `${marketId}:${side}`; }

  // Positions in markets still trading plus buys in flight, so the cap holds while orders travel. A position whose
  // market has ended no longer takes a place: it is being cashed out or waits only for its result.
  openCount() {
    const inflight = [...this.pending].filter((k) => !this.acct.positions[k]).length;
    const live = Object.values(this.acct.positions).filter((p) => {
      const m = this.getMarket(p.marketId);
      return !(m && (this.ended(m) || (m.resolved && m.winner != null)));
    }).length;
    return live + inflight;
  }

  // Has the engine already traded this market's window? Then it waits for the next window.
  windowUsed(m) {
    const end = m && this.acct.windows && this.acct.windows[m.id];
    return end != null && this.nowMs() < (m.endMs || end);
  }
  minShares(m, side = 0) {
    const orderMin = m && m.executionMeta && m.executionMeta[side] && m.executionMeta[side].minOrder;
    return orderMin || (m && m.minOrder) || 5;
  }
  // Why your real Polymarket account could not place this order right now, or null. Asked only with `realAccount` on;
  // otherwise the demo balance pays and only Polymarket's order rules apply.
  accountGate(req) {
    if (!this.settings.realAccount) return null;
    return this.realGate ? this.realGate(req) : "real-account eligibility check is unavailable";
  }

  // Can an order trade on this market right now? Past its end time or not accepting orders, it cannot.
  isOpen(m) {
    if (!m || m.closed || m.resolved || m.active === false || m.acceptingOrders === false) return false;
    return !(m.endMs && this.nowMs() >= m.endMs);
  }

  // Can a position still be sold? The exchange keeps taking orders after a market's window ends, until the result is
  // settled, so this depends on the venue being open, not on the window.
  canSell(m) { return !!m && !m.closed && !m.resolved && m.active !== false && m.acceptingOrders !== false; }
  // Has the market's trading window ended (result not yet settled, or settled)?
  ended(m) { return !!(m && m.endMs && this.nowMs() >= m.endMs); }

  // Arm the account's default exits on a new position.
  armDefaults(p, m) {
    const s = this.settings;
    if (s.autoTpPct > 0) { const x = this.takeProfitPrice(p, m, s.autoTpPct / 100); if (x != null) p.tp = { price: x, setAt: this.nowMs(), auto: true }; }
    if (s.autoSlPct > 0) { const x = this.stopLossPrice(p, m, s.autoSlPct / 100); if (x != null) p.sl = { price: x, setAt: this.nowMs(), auto: true }; }
  }

  // How long this order takes to reach the book.
  latency() {
    const s = this.settings;
    if (!s.strict) return s.latencyMs;
    let ms = s.latencyMs * (1 - s.latencyJitter + 2 * s.latencyJitter * this.random());
    if (this.random() < s.spikeChance) ms += s.spikeMs * this.random();
    return Math.max(0, Math.round(ms));
  }
  async delay() { const ms = this.latency(); if (ms > 0) await this.sleep(ms); }

  // The part of a book side we can actually trade against, after other traders take their share.
  available(levels) {
    const share = this.settings.strict ? this.settings.fillShare : 1;
    return share >= 1 ? levels : levels.map((l) => ({ price: l.price, size: l.size * share }));
  }

  orderabilityMiss(m, side = 0) {
    if (!m || m.restricted) return "market is geo-restricted";
    if (m.version !== "v1" && m.version !== "v2") return "unsupported or unknown market protocol version";
    if (!m.enableOrderBook || m.acceptingOrders === false) return "market is not accepting CLOB orders";
    if (!m.tokenIds || !m.tokenIds[side]) return "market outcome asset ID is unavailable";
    const meta = m.executionMeta && m.executionMeta[side];
    if (!meta || !(meta.tickSize > 0) || !(meta.minOrder > 0) || typeof meta.negRisk !== "boolean") {
      return "current CLOB tick size, minimum size, or negative-risk metadata is unavailable";
    }
    if (meta.version !== m.version) return "CLOB book protocol version does not match the market";
    if (meta.negRisk !== !!m.negRisk) return "CLOB negative-risk metadata does not match the market";
    const book = m.books && m.books[side];
    if (!book) return "current outcome order book is unavailable";
    for (const level of [...(book.bids || []), ...(book.asks || [])]) {
      const ticks = level.price / meta.tickSize;
      if (!(level.price > 0 && level.price < 1) || Math.abs(ticks - Math.round(ticks)) > 1e-6) {
        return "order book contains a price outside the current tick size";
      }
    }
    if (!m.booksAt || this.nowMs() - m.booksAt > this.settings.maxBookAgeMs) return "order book or its constraints are stale";
    return null;
  }

  // Reasons an order that reached the book still fails; null when it goes through.
  frictionMiss(m, side = 0) {
    const s = this.settings;
    const orderability = this.orderabilityMiss(m, side);
    if (orderability) return orderability;
    if (s.strict && this.random() < s.rejectChance) return "rejected by the venue";
    return null;
  }

  async onSignal(sig, m) {
    if (!this.settings.autoTrade) return;
    if (sig.kind === "arbitrage" && sig.arb) return this.buyArb(sig, m);
    if (this.openCount() >= this.settings.maxPositions) {
      this.log({ side: "BUY", status: "skipped", question: sig.question, outcome: sig.outcome, reason: `already holding ${this.settings.maxPositions} positions` });
      this.save(); return;
    }
    return this.buy(m, sig.side, this.tradeUsd(m, sig.side), sig);
  }

  // Buy one outcome token with up to `budget` USD: a limit order at the quoted ask + maxSlippage, filled against the
  // book as it stands once the order arrives.
  async buy(m, side, budget, sig = null) {
    const key = this.posKey(m.id, side);
    if (this.pending.has(key)) return;
    let base = { side: "BUY", marketId: m.id, pside: side, question: m.question, outcome: m.outcomes[side] };
    if (!this.isOpen(m)) { this.log({ ...base, status: "skipped", reason: "market closed to new orders" }); this.save(); return; }
    if (sig && this.windowUsed(m)) { this.log({ ...base, status: "skipped", reason: "this market window was already traded: waiting for the next window" }); this.save(); return; }
    const orderability = this.orderabilityMiss(m, side);
    if (orderability) { this.log({ ...base, status: "skipped", reason: orderability }); this.save(); return; }
    const gate = this.accountGate({ action: "buy", amount: budget, market: m, sig });
    if (gate) { this.log({ ...base, status: "skipped", reason: `not executable on your real account: ${gate}` }); this.save(); return; }
    if (budget < 1 || budget > this.acct.cash + 1e-9) { this.log({ ...base, status: "skipped", reason: "not enough cash" }); this.save(); return; }
    const quoted = m.ask(side);
    if (quoted == null || !m.asks(side).length) { this.log({ ...base, status: "skipped", reason: "no asks on the book" }); this.save(); return; }
    const meta = m.executionMeta[side];
    const minShares = this.minShares(m, side);
    let limit = floorToTick(Math.min(1 - meta.tickSize, quoted + this.settings.maxSlippage), meta.tickSize);
    if (limit < quoted - 1e-9 || limit <= 0) {
      this.log({ ...base, status: "skipped", reason: "best ask does not conform to the current CLOB tick size" }); this.save(); return;
    }
    if (budget / (limit + feePerShare(m, limit)) < minShares - 1e-9) {
      this.log({ ...base, status: "skipped", reason: `not enough cash for the ${minShares}-share minimum` }); this.save(); return;
    }
    this.pending.add(key);
    const epoch = this.epoch;
    try {
      if (this.hands) {
        const r = await this.hands({ action: "buy", market: m, side, amount: budget, decisionPrice: quoted, sig });
        if (epoch !== this.epoch) return;
        base = { ...base, hands_id: r && r.id, hands_ms: r && r.ms, ui: r && r.ui, decision_ask: quoted };
        if (r && r.notExecutable) { this.log({ ...base, status: "skipped", reason: `${refusal(r)}: ${r.reason}` }); return; }
        if (!r || !r.ok) { this.log({ ...base, status: "missed", reason: `hands: ${(r && r.reason) || "no answer"}` }); return; }
        const ready = this.getMarket(m.id) || m;
        const readyAsk = ready.ask(side);
        if (readyAsk == null) { this.log({ ...base, status: "missed", reason: "no asks when the screen was ready" }); return; }
        const readyMeta = ready.executionMeta && ready.executionMeta[side];
        if (!readyMeta || !(readyMeta.tickSize > 0)) { this.log({ ...base, status: "missed", reason: "current CLOB tick size is unavailable" }); return; }
        limit = floorToTick(Math.min(1 - readyMeta.tickSize, readyAsk + this.settings.maxSlippage), readyMeta.tickSize);
        base.click_ask = readyAsk;
      }
      await this.delay();
      if (epoch !== this.epoch) return;
      const live = this.getMarket(m.id) || m;
      if (!this.isOpen(live)) { this.log({ ...base, status: "missed", reason: "market closed before the order arrived" }); return; }
      const friction = this.frictionMiss(live, side);
      if (friction) { this.log({ ...base, status: "missed", reason: friction }); return; }
      const fill = walkAsks(this.available(live.asks(side)), budget, limit, 2);
      const minOrder = this.minShares(live);
      if (fill.shares <= 1e-9) { this.log({ ...base, status: "missed", reason: `ask moved above the ${cents(limit)} limit before the order arrived` }); return; }
      // fill-and-kill: what the book had within the limit is bought, even below the minimum (it then cannot be sold)
      const partialNote = fill.shares < minOrder - 1e-9 ? ` · only ${fill.shares.toFixed(2)} shares were there: below the ${minOrder}-share minimum, so they cannot be sold and are held to the result` : "";
      const fee = fill.levels.reduce((total, level) => total + feeForFill(live, level.price, level.shares), 0);
      const cost = fill.spent + fee;
      if (cost > this.acct.cash + 1e-9) { this.log({ ...base, status: "skipped", reason: "cash moved; fill too large" }); return; }
      this.acct.cash -= cost;
      this.acct.totals.fees += fee; this.acct.totals.invested += fill.spent;
      const p = this.acct.positions[key];
      if (p) { p.shares += fill.shares; p.cost += cost; p.avg = p.cost / p.shares; }
      else {
        this.acct.positions[key] = {
          key, marketId: live.id, side, tokenId: live.tokenIds[side], question: live.question, event: live.eventTitle,
          outcome: live.outcomes[side], shares: fill.shares, cost, avg: cost / fill.shares, opened: this.nowMs(),
          kind: sig ? sig.kind : "manual", arbGroup: null,
        };
        this.armDefaults(this.acct.positions[key], live);
      }
      this.acct.windows[live.id] = live.endMs || this.nowMs() + 3600e3;
      this.log({ ...base, status: "filled", shares: fill.shares, avg_price: fill.avgPrice, fee, cost,
        reason: (sig ? (sig.kind === "arbitrage" ? "risk-free set" : `${sig.kind === "exploratory" ? "exploratory" : "signal"} ${sig.agree}/25${sig.model ? ` · ${sig.model.secs_to_end} s to the close · ${live.outcomes[side]} ${(100 * (side === 0 ? sig.model.p_up : 1 - sig.model.p_up)).toFixed(0)}% vs ${cents(sig.model.cost)} all-in` : ""} · edge ${(sig.edge * 100).toFixed(1)}¢`) : "manual")
          + (fill.avgPrice > quoted + 1e-9 ? ` · slipped ${cents(fill.avgPrice - quoted)} vs ${base.click_ask != null ? "decision" : "quote"}` : "") + partialNote });
      return this.acct.positions[key];
    } finally { this.pending.delete(key); this.save(); }
  }

  // Buy one share of every outcome in a risk-free set, sized to the budget cap. Each leg is its own limit order; they
  // reach the book together after the latency, and each fills or misses on its own.
  async buyArb(sig, anyMember) {
    const arb = sig.arb;
    const group = `arb:${sig.id}`;
    const skip = (reason) => { this.log({ side: "ARB", status: "skipped", question: sig.eventTitle, reason }); this.save(); };
    if (this.pending.has(group)) return;
    const members = (arb.memberIds || []).map((id) => this.getMarket(id)).filter((m) => m && m.books && m.asks(0).length);
    if (members.length < (arb.members || 2) || members.length < 2) return skip("set members not fully loaded");
    if (!members.every((m) => this.isOpen(m))) return skip("a market in the set is closed to new orders");
    const notOrderable = members.find((m) => this.orderabilityMiss(m, 0));
    if (notOrderable) return skip(this.orderabilityMiss(notOrderable, 0));
    const quotes = members.map((m) => m.ask(0));
    const perSet = members.reduce((s, m, i) => s + quotes[i] + feePerShare(m, quotes[i]), 0);
    if (perSet <= 0 || perSet >= 1) return skip("no live sub-$1 set");
    const limits = quotes.map((q, i) => {
      const tick = members[i].executionMeta[0].tickSize;
      return floorToTick(Math.min(1 - tick, q + this.settings.maxSlippage), tick);
    });
    const perSetAtLimit = members.reduce((s, m, i) => s + limits[i] + feePerShare(m, limits[i]), 0);
    const budget = Math.min(this.settings.arbMaxUsd, this.acct.cash);
    const sets = Math.floor(budget / perSetAtLimit);
    const minOrder = Math.max(...members.map((m) => this.minShares(m, 0)));
    if (sets < minOrder) return skip(`${sets} set(s) affordable; each leg needs the ${minOrder}-share minimum`);

    this.pending.add(group);
    const epoch = this.epoch;
    try {
      await this.delay();
      if (epoch !== this.epoch) return;
      const legs = members.map((m, i) => {
        const live = this.getMarket(m.id) || m;
        const none = { shares: 0, spent: 0, avgPrice: null };
        const lost = this.frictionMiss(live, 0) || (this.settings.strict && this.random() < this.settings.arbLegMissChance);
        const fill = this.isOpen(live) && !lost ? walkAsksShares(this.available(live.asks(0)), sets, limits[i]) : none;
        const fee = fill.levels.reduce((total, level) => total + feeForFill(live, level.price, level.shares), 0);
        return { m: live, shares: fill.shares, spent: fill.spent, fee, px: fill.avgPrice };
      });
      const filled = legs.filter((l) => l.shares > 1e-9);
      if (!filled.length) return skip("every leg's ask moved past its limit before the orders arrived");
      let totalCost = 0, totalFee = 0;
      for (const l of filled) { totalCost += l.spent + l.fee; totalFee += l.fee; }
      this.acct.cash -= totalCost; this.acct.totals.fees += totalFee; this.acct.totals.invested += totalCost - totalFee;

      if (filled.length === legs.length && legs.every((l) => l.shares >= sets - 1e-6)) {
        for (const leg of legs) {
          const k = this.posKey(leg.m.id, 0) + ":" + group;
          this.acct.positions[k] = {
            key: k, marketId: leg.m.id, side: 0, tokenId: leg.m.tokenIds[0], question: leg.m.question,
            event: leg.m.eventTitle, outcome: leg.m.outcomes[0], shares: leg.shares, cost: leg.spent + leg.fee,
            avg: (leg.spent + leg.fee) / leg.shares, opened: this.nowMs(), kind: "arbitrage", arbGroup: group, legs: legs.length,
          };
        }
        this.log({ side: "ARB", status: "filled", question: sig.eventTitle, reason: `${sets} set(s) of ${legs.length} outcomes for ${usd(totalCost)} → guaranteed ${usd(sets)} at resolution`,
          shares: sets, cost: totalCost, fee: totalFee, guaranteed: sets, edge: sets - totalCost });
        return;
      }

      // Leg risk: some orders missed, so what filled is no longer a hedged set. Keep it as ordinary positions.
      for (const leg of filled) {
        const k = this.posKey(leg.m.id, 0), cost = leg.spent + leg.fee;
        const p = this.acct.positions[k];
        if (p) { p.shares += leg.shares; p.cost += cost; p.avg = p.cost / p.shares; }
        else {
          this.acct.positions[k] = {
            key: k, marketId: leg.m.id, side: 0, tokenId: leg.m.tokenIds[0], question: leg.m.question,
            event: leg.m.eventTitle, outcome: leg.m.outcomes[0], shares: leg.shares, cost,
            avg: cost / leg.shares, opened: this.nowMs(), kind: "arb-leg", arbGroup: null,
          };
          this.armDefaults(this.acct.positions[k], leg.m);
        }
      }
      this.log({ side: "ARB", status: "broken", question: sig.eventTitle, cost: totalCost, fee: totalFee,
        reason: `${filled.length}/${legs.length} legs filled before prices moved; ${usd(totalCost)} now sits in unhedged positions` });
    } finally { this.pending.delete(group); this.save(); }
  }

  // Sell a whole position: a limit order at the quoted bid - maxSlippage, filled against the book once it arrives.
  // Before the market's end it goes through the hands, if any; after the end polymarket.com shows no trade panel, so it
  // is sent straight to the exchange (marked `api`).
  async sellAll(marketId, side, reason) {
    const key = this.posKey(marketId, side);
    const p = this.acct.positions[key];
    if (!p || this.pending.has(key)) return;
    const m = this.getMarket(marketId);
    let base = { side: "SELL", marketId, pside: side, question: p.question, outcome: p.outcome };
    if (m && !this.canSell(m)) {
      if (!p.closedLogged) { p.closedLogged = true; this.log({ ...base, status: "skipped", reason: "market closed; waiting for resolution" }); }
      this.save(); return;
    }
    if (!m || !m.bids(side).length) {
      if (reason === "manual" || !p.noBidLogged) { p.noBidLogged = true; this.log({ ...base, status: "skipped", reason: "no bids to sell into" }); }
      this.save(); return;
    }
    if (p.shares < this.minShares(m, side) - 1e-9) {
      if (reason === "manual" || !p.minLogged) { p.minLogged = true; this.log({ ...base, status: "skipped", reason: `${p.shares.toFixed(2)} shares is below Polymarket's ${this.minShares(m, side)}-share minimum order: a real account could not sell it, so it is held to the result` }); }
      this.save(); return;
    }
    const orderability = this.orderabilityMiss(m, side);
    if (orderability) {
      if (reason === "manual" || !p.orderabilityLogged) { p.orderabilityLogged = true; this.log({ ...base, status: "skipped", reason: orderability }); }
      this.save(); return;
    }
    const gate = this.accountGate({ action: "sell", shares: p.shares, market: m });
    if (gate) {
      if (reason === "manual" || !p.gateLogged) { p.gateLogged = true; this.log({ ...base, status: "skipped", reason: `not executable on your real account: ${gate}` }); }
      this.save(); return;
    }
    const decisionBid = m.bid(side);
    const initialMeta = m.executionMeta[side];
    let limit = Math.max(initialMeta.tickSize, ceilToTick(Math.max(initialMeta.tickSize, decisionBid - this.settings.maxSlippage), initialMeta.tickSize));
    if (this.hands && this.ended(m)) base.api = true;
    this.pending.add(key);
    try {
      if (this.hands && !base.api) {
        const r = await this.hands({ action: "sell", market: m, side, shares: p.shares, decisionPrice: decisionBid, reason });
        if (this.acct.positions[key] !== p) return;
        base = { ...base, hands_id: r && r.id, hands_ms: r && r.ms, ui: r && r.ui, decision_bid: decisionBid };
        if (r && r.notExecutable) { this.log({ ...base, status: "skipped", reason: `${refusal(r)}: ${r.reason}` }); return; }
        if (!r || !r.ok) { this.log({ ...base, status: "missed", reason: `hands: ${(r && r.reason) || "no answer"}` }); return; }
        const readyBid = (this.getMarket(marketId) || m).bid(side);
        if (readyBid == null) { this.log({ ...base, status: "missed", reason: "no bids when the screen was ready" }); return; }
        const readyMeta = (this.getMarket(marketId) || m).executionMeta[side];
        if (!readyMeta || !(readyMeta.tickSize > 0)) { this.log({ ...base, status: "missed", reason: "current CLOB tick size is unavailable" }); return; }
        limit = Math.max(readyMeta.tickSize, ceilToTick(Math.max(readyMeta.tickSize, readyBid - this.settings.maxSlippage), readyMeta.tickSize));
        base.click_bid = readyBid;
      }
      await this.delay();
      if (this.acct.positions[key] !== p) return; // settled (or the account was reset) while the order was travelling
      const live = this.getMarket(marketId) || m;
      if (!this.canSell(live)) { this.log({ ...base, status: "missed", reason: "market closed before the order arrived" }); return; }
      const friction = this.frictionMiss(live, side);
      if (friction) { this.log({ ...base, status: "missed", reason: friction }); return; }
      const fill = walkBids(this.available(live.bids(side)), p.shares, limit, 2);
      if (fill.sold <= 1e-9) { this.log({ ...base, status: "missed", reason: `bid moved below the ${cents(limit)} limit before the order arrived` }); return; }
      const fee = fill.levels.reduce((total, level) => total + feeForFill(live, level.price, level.shares), 0);
      const proceeds = fill.proceeds - fee;
      this.acct.cash += proceeds; this.acct.totals.fees += fee;
      const costShare = p.cost * (fill.sold / p.shares);
      this.acct.totals.realized += proceeds - costShare;
      this.log({ ...base, status: "filled", shares: fill.sold, avg_price: fill.avgPrice, proceeds, pnl: proceeds - costShare, reason });
      p.shares -= fill.sold; p.cost -= costShare;
      if (p.shares < 1e-6) delete this.acct.positions[key];
    } finally { this.pending.delete(key); this.save(); }
  }

  // ---------------------------------------------------------------- take profit and stop loss

  // Arm (price 0–1, per share) or clear (null) the take-profit or stop-loss of a position.
  setExit(which, key, price) {
    const p = this.acct.positions[key];
    if (!p) return { ok: false, reason: "no open position" };
    if (p.kind === "arbitrage" && p.arbGroup) return { ok: false, reason: "a risk-free set is held to its $1 payout" };
    if (price == null) { delete p[which]; this.save(); return { ok: true, price: null }; }
    const v = Math.round(Number(price) * 1000) / 1000;
    if (!(v > 0 && v < 1)) return { ok: false, reason: `the ${which === "tp" ? "target" : "stop"} must be between 0¢ and 100¢` };
    p[which] = { price: v, setAt: this.nowMs() };
    this.save();
    return { ok: true, price: v };
  }
  setTakeProfit(key, price) { return this.setExit("tp", key, price); }
  setStopLoss(key, price) { return this.setExit("sl", key, price); }

  // The highest whole-cent bid at which selling loses at least `pct` (0.25 = 25%) of what the position cost, after
  // the taker fee; null when even 1¢ would not (a stop that low could never matter).
  stopLossPrice(p, m, pct) {
    const floor = p.avg * (1 - pct);
    for (let c = 99; c >= 1; c--) {
      const x = c / 100;
      if (x - feePerShare(m, x) <= floor + 1e-9) return x;
    }
    return null;
  }

  // The lowest whole-cent bid at which selling returns `pct` (0.25 = 25%) on what the position cost, after the
  // taker fee; null when even 99¢ would not.
  takeProfitPrice(p, m, pct) {
    const want = p.avg * (1 + pct);
    for (let c = 1; c <= 99; c++) {
      const x = c / 100;
      if (x - feePerShare(m, x) >= want - 1e-9) return x;
    }
    return null;
  }

  // Profit after fees, as a fraction of cost, of selling at bid `price`.
  takeProfitPct(p, m, price) { return p.avg > 0 ? (price - feePerShare(m, price)) / p.avg - 1 : null; }

  // Sell every position whose best bid has reached its target or fallen to its stop, if it can be sold right now.
  // Called on every price update, so an exit fires on the first quote that reaches it.
  checkExits(marketId = null) {
    const now = this.nowMs();
    for (const p of Object.values(this.acct.positions)) {
      if ((!p.tp && !p.sl) || (marketId != null && p.marketId !== marketId) || this.pending.has(p.key)) continue;
      if (p.key !== this.posKey(p.marketId, p.side)) continue; // complete arbitrage sets are never sold
      if (now - (p.exitTriedAt || 0) < TP_RETRY_MS) continue;
      const m = this.getMarket(p.marketId);
      if (!m || !m.books || !this.canSell(m) || p.shares < this.minShares(m) - 1e-9) continue;
      const bid = m.bid(p.side);
      if (bid == null || bid <= 0) continue;
      let reason = null;
      if (p.tp && bid >= p.tp.price - 1e-9) reason = `take profit: bid ${cents(bid)} reached the ${cents(p.tp.price)} target`;
      else if (p.sl && bid <= p.sl.price + 1e-9) reason = `stop loss: bid ${cents(bid)} fell to the ${cents(p.sl.price)} stop`;
      if (!reason) continue;
      p.exitTriedAt = now;
      this.sellAll(p.marketId, p.side, reason).catch((e) => console.error("exit", e));
    }
  }
  checkTakeProfits(marketId = null) { return this.checkExits(marketId); }

  // Settle resolved markets, try a pre-close exit while the window is open, and sell to the waiting buyers once it
  // has ended (if `afterEnd` is "sell").
  async monitor() {
    this.checkExits();
    let changed = false;
    for (const [id, end] of Object.entries(this.acct.windows || {})) if (this.nowMs() - end > 3600e3) { delete this.acct.windows[id]; changed = true; }
    for (const p of Object.values(this.acct.positions)) {
      if (this.pending.has(p.key)) continue;
      let m = this.getMarket(p.marketId);
      if ((!m || !m.resolved) && this.client && this.nowMs() - (p._checkedAt || 0) > 60000) {
        p._checkedAt = this.nowMs();
        const fresh = await this.client.market(p.marketId).catch(() => null);
        if (fresh) { m = fresh; this.onMarket?.(fresh); }
      }
      if (m && m.resolved && m.winner != null) {
        p.resolvedSeenAt ||= this.nowMs();
        const wait = this.settings.strict ? this.settings.settleDelayMs : 0;
        if (this.nowMs() - p.resolvedSeenAt < wait) continue; // winnings not redeemed yet
        const payout = m.winner === p.side ? p.shares * 1 : 0;
        this.acct.cash += payout;
        this.acct.totals.realized += payout - p.cost;
        this.log({ side: "SETTLE", marketId: p.marketId, pside: p.side, status: m.winner === p.side ? "win" : "loss",
          question: p.question, outcome: p.outcome, proceeds: payout, pnl: payout - p.cost, reason: `resolved to ${m.outcomes[m.winner]}` });
        delete this.acct.positions[p.key];
        changed = true;
      } else if (m && p.kind !== "arbitrage" && m.endMs && this.isOpen(m) && this.settings.exitBeforeEndMs > 0
        && m.endMs - this.nowMs() <= this.settings.exitBeforeEndMs
        && this.nowMs() - (p.expiryCloseAttemptAt || 0) >= 5000) {
        p.expiryCloseAttemptAt = this.nowMs();
        await this.sellAll(p.marketId, p.side, "exit before market close");
      } else if (m && p.kind !== "arbitrage" && p.key === this.posKey(p.marketId, p.side) && this.settings.afterEnd === "sell"
        && this.ended(m) && this.canSell(m) && m.books && p.shares >= this.minShares(m) - 1e-9
        && this.nowMs() - (p.endSellAttemptAt || 0) >= END_SELL_RETRY_MS) {
        p.endSellAttemptAt = this.nowMs();
        if (m.bids(p.side).length) {
          await this.sellAll(p.marketId, p.side, "market ended: sold to the buyers waiting on the book instead of waiting for the result");
        } else if (!p.endNoBidLogged) {
          p.endNoBidLogged = true;
          this.log({ side: "SELL", marketId: p.marketId, pside: p.side, question: p.question, outcome: p.outcome, status: "skipped",
            reason: "market ended and nobody is buying this side (usually the losing side, worth $0): waiting for the result" });
          changed = true;
        }
      }
    }
    if (changed) this.save();
  }

  // What an open position is worth now. A complete arbitrage set is worth its guaranteed payout: $1 per set, shared
  // across the legs still open in proportion to what each cost. Anything else is worth what selling it into the bid
  // ladder would return after the taker fee; once trading has stopped, nothing can be sold, so it is carried at the
  // last mid (the market's estimate of its $1/$0 payout) until resolution.
  valuePosition(p, m, groupCost = null) {
    if (p.kind === "arbitrage" && p.arbGroup) {
      const total = groupCost ?? Object.values(this.acct.positions).filter((q) => q.arbGroup === p.arbGroup).reduce((a, q) => a + q.cost, 0);
      return total > 0 ? p.shares * p.cost / total : p.shares / (p.legs || 1);
    }
    if (m && m.resolved && m.winner != null) return m.winner === p.side ? p.shares : 0; // awaiting redemption
    if (!m || !m.books) return p.shares * p.avg; // book not loaded yet: carried at cost
    if (!this.canSell(m)) return p.shares * (m.mid(p.side) ?? 0);
    const fill = walkBids(m.bids(p.side), p.shares);
    return Math.max(0, fill.proceeds - feePerShare(m, fill.avgPrice || 0) * fill.sold);
  }

  snapshot() {
    const px = this.nowMs();
    let openValue = 0, openCost = 0;
    const groupCost = {};
    for (const p of Object.values(this.acct.positions)) if (p.arbGroup) groupCost[p.arbGroup] = (groupCost[p.arbGroup] || 0) + p.cost;
    const positions = Object.values(this.acct.positions).map((p) => {
      const m = this.getMarket(p.marketId);
      const value = this.valuePosition(p, m, p.arbGroup ? groupCost[p.arbGroup] : null);
      const mark = p.shares > 0 ? value / p.shares : null;
      openValue += value; openCost += p.cost;
      const pnlUsd = value - p.cost;
      return {
        key: p.key, marketId: p.marketId, question: p.question, event: p.event, outcome: p.outcome, side: p.side,
        shares: Math.round(p.shares * 100) / 100, avg: p.avg, mark, value, cost: p.cost,
        pnl_usd: pnlUsd, pnl_pct: p.cost > 0 ? (value / p.cost - 1) * 100 : 0, kind: p.kind,
        resolves_in_h: m ? m.hoursToEnd(px) : null, market_open: this.isOpen(m), tradable: this.canSell(m), has_bids: !!(m && m.bids(p.side).length),
        ended: !!(m && this.ended(m) && !(m.resolved && m.winner != null)),
        below_min: p.shares < this.minShares(m) - 1e-9, min_shares: this.minShares(m),
        resolved: !!(m && m.resolved && m.winner != null), pending: this.pending.has(p.key), opened: p.opened || 0,
        bid: m && m.books ? m.bid(p.side) : null,
        tp: p.tp ? p.tp.price : null, tp_pct: p.tp ? this.takeProfitPct(p, m, p.tp.price) : null,
        tp_allowed: !(p.kind === "arbitrage" && p.arbGroup),
        tp_options: p.kind === "arbitrage" && p.arbGroup ? [] : TP_PRESETS.map((pct) => ({ pct, price: this.takeProfitPrice(p, m, pct / 100) })),
        sl: p.sl ? p.sl.price : null, sl_pct: p.sl ? this.takeProfitPct(p, m, p.sl.price) : null,
        sl_options: p.kind === "arbitrage" && p.arbGroup ? [] : SL_PRESETS.map((pct) => ({ pct, price: this.stopLossPrice(p, m, pct / 100) })),
      };
    });
    const equity = this.acct.cash + openValue;
    const t = this.acct.totals;
    // settled directional / arb results
    const settles = this.acct.trades.filter((x) => x.side === "SETTLE");
    const wins = settles.filter((x) => x.status === "win").length;
    return {
      funded: true, start_usd: this.acct.startUsd, cash: this.acct.cash, open_value: openValue, open_cost: openCost,
      equity, pnl_usd: equity - this.acct.startUsd, pnl_pct: (equity / this.acct.startUsd - 1) * 100,
      unrealized_pnl_usd: openValue - openCost,
      settings: { ...this.settings },
      totals: { fees: t.fees, realized: t.realized, invested: t.invested },
      settled: settles.length, settled_wins: wins,
      // oldest first, so rows keep their place as prices move
      positions: positions.sort((a, b) => (a.opened - b.opened) || (a.key < b.key ? -1 : 1)),
      trades: this.acct.trades.slice(0, 50),
    };
  }
}
