// The engine behind the Start / Stop button, running inside the page (or the server, or the extension).
//
// It trades one thing: Polymarket's five-minute crypto markets ("Bitcoin Up or Down", eight coins, each switchable on
// or off), and only in the last seconds before a window closes, when the Chainlink price against the price to beat
// nearly decides the result (see closing.js). Start launches concurrent loops:
//   events    Gamma: the five-minute events of the next 45 minutes (the "5M" tag)
//   prices    Polymarket's live-data socket: the Chainlink price of every coin, once a second
//   books     CLOB: live order books. With the stream, every current window is on it (no lag); with data saver, the
//             windows about to close are read every 0.5 s and the rest every 10 s
//   council   all 25 agents vote on each market, both sides; a market in its closing window is judged again at once on
//             every price or book change (at most every 0.1 s), so an entry goes out on the update that makes it
//   paper     value the demo account's positions and settle resolved markets
// Stop aborts them all.
//
// The loops never stop by themselves. A pass that fails (a network outage, a reply the code did not expect) is
// recorded in `health` and retried; the live price stream is replaced when it goes quiet without closing (a network
// change or a computer waking from sleep leaves such a connection behind); and if no new data has arrived for a few
// minutes all feeds are restarted. `status.data` says how fresh the markets and prices are.

import {
  AGENTS, AGENTS_BY_ID, Market, arbForEvent, buildSignal, compareRank, defaultRules, isFastCryptoMarket, runCouncil, scoreSignal,
} from "./core.js";
import { MARKET_WS, PolyClient, attachBooks, parseBook, sleep } from "./sources.js";
import { PaperAccount } from "./paper.js";
import { COIN_IDS, ClosingDesk, coinLabel, fiveMinute } from "./closing.js";

const CANDIDATE_CAP = 16;   // markets that get books + council: the current and next window of each of the eight coins
const WATCH_CAP = 12000;    // markets kept in memory (a sweep sees about 2,000-4,000)
// How long the engine waits for things (milliseconds). Each engine keeps its own copy, so a test can shorten them.
export const TIMING = {
  sweepMs: 25000,          // markets are re-read this often
  sweepRetryMs: 5000,      // ... and this soon after a sweep that brought nothing
  pingMs: 10000,           // the price stream is pinged this often (it answers every ping)
  streamQuietMs: 30000,    // this long without a word from the stream, it is replaced
  streamOpenMs: 15000,     // a stream connection that has not opened by then is given up and retried
  staleRestartMs: 180000,  // no new markets or prices for this long while running: the feeds are restarted
  restartGapMs: 300000,    // at most one such restart per five minutes
  errorPauseMs: 2000,      // pause after a loop pass that failed, before the next
  councilMs: 1000,         // the council votes this often ...
  councilDebounceMs: 250,  // ... and after price updates, at most once per this (a busy stream sends ~20 a second)
  reconnectMs: 500,        // first pause before the price stream is reopened; it doubles up to 10 s while it fails
  closingPollMs: 500,      // without the stream, the books of windows about to close are read this often ...
  otherBooksMs: 10000,     // ... and the others this often
  preRollS: 20,            // a window is "about to close" this long before its entry window opens
  evalThrottleMs: 100,     // a closing market is judged again on each update, at most this often
};
// What the engine watches. The normal set suits a computer on a home connection: the order-book stream of every
// current five-minute window (no lag; about 1.5–2 GB an hour for all eight coins, measured, since market makers
// re-quote these books many times a second).
const FULL_OPTIONS = { stream: true, candidateCap: CANDIDATE_CAP, arbitrage: false, eventTag: "5M", sweepHours: 0.75 };
// Data saver, for a phone or a metered connection: no order-book stream. The books of the windows about to close are
// read every 0.5 s (one compressed request, about 6 KB for all eight coins) and the others every 10 s; the events are
// listed once a minute. The Chainlink prices still arrive live (about 2 KB a second). Measured: about 18 MB an hour.
export const DATA_SAVER = { stream: false, candidateCap: CANDIDATE_CAP, arbitrage: false, eventTag: "5M", sweepHours: 0.75, sweepMs: 60000 };
// The closing-window rules a person can change, and their starting values.
export const CLOSING_DEFAULTS = { entry_window_s: 60, entry_stop_s: 4, coins: Object.fromEntries(COIN_IDS.map((c) => [c, true])) };
const SAVED_RULES = ["min_buy_votes", "min_edge", "min_arb_edge", "max_resolve_hours", "entry_window_s", "entry_stop_s", "coins"];

function storageGet(key) { try { return JSON.parse(localStorage.getItem(key) || "null"); } catch { return null; } }
function storageSet(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* ignore */ } }

export class Engine {
  constructor() {
    const savedRules = storageGet("polyscan.rules") || {};
    this.rules = { ...defaultRules(), ...CLOSING_DEFAULTS, ...savedRules };
    if ((savedRules.strategy_version || 0) < 2) this.rules.max_resolve_hours = 1;
    if ((savedRules.strategy_version || 0) < 5) this.rules.min_buy_votes = 12;
    if ((savedRules.strategy_version || 0) < 6) this.rules.min_edge = defaultRules().min_edge; // closing-window entries
    this.rules.coins = { ...CLOSING_DEFAULTS.coins, ...(savedRules.coins || {}) };
    this.saveRules();
    this.running = false;
    this.started_at = null;
    this.markets = new Map();   // id -> Market
    this.events = new Map();    // id -> parsed event
    this.marketEvent = new Map(); // marketId -> eventId
    this.marketsVersion = 0;    // goes up whenever a market is added, replaced, removed or resolved (candidates() keys on it)
    this.signals = (storageGet("polyscan.signals") || []).slice(-300);
    this.status = {};
    this.analyzed = new Set();
    this.events_seen = 0;
    this.passes = 0;
    this.last_pass_ms = 0;
    this.agent_tally = {};
    this.abort = null;
    this.client = null;
    this.marketSocket = null;
    this.marketHeartbeat = null;
    this.marketReconnectTimer = null;
    this.marketReconnectDelay = 500;
    this.marketStreamInitialized = false;
    this.subscribedAssets = new Set();
    this.marketAssetRefs = new Map();
    this.desiredAssetRefs = new Map();
    this.lastRestBooksAt = 0;
    this.councilScheduled = false;
    this.councilTimer = null;
    this.timing = { ...TIMING };
    this.options = { ...FULL_OPTIONS };
    this.dataSaver = false;
    // When data last arrived, and what went wrong: read by the freshness status and the stale-feed restart.
    this.health = { marketsAt: 0, pricesAt: 0, streamAt: 0, sweeps: 0, errors: 0, lastError: null, lastErrorAt: 0, reconnects: 0, restarts: 0, restartedAt: 0, startedAt: 0 };
    this.paper = new PaperAccount({ nowMs: () => Date.now(), getMarket: (id) => this.markets.get(id) });
    // The closing desk: live Chainlink prices, the price to beat, the settlement model and what it has learnt.
    this.desk = new ClosingDesk({ clock: () => this.clock(), load: () => storageGet("polyscan.closing"), save: (v) => storageSet("polyscan.closing", v) });
    this.desk.feed.onTick = (coin) => this.onPrice(coin);
    this._evalAt = new Map();
    this._evalQueued = new Set();
    this.onChange = null; // called (at most every few hundred ms by the listener's own choice) when something worth showing changed
    // A held market fetched directly (it has left the scan window) joins the map, so it gets a live book, a mark and
    // a sell button; a resolution seen that way replaces the stale copy.
    this.paper.onMarket = (fresh) => {
      const prev = this.markets.get(fresh.id);
      if (prev && (prev.resolved || !fresh.resolved)) return;
      if (prev) { fresh.books = prev.books; fresh.booksAt = prev.booksAt; fresh.fastTape = prev.fastTape; }
      this.markets.set(fresh.id, fresh);
      this.marketsVersion++;
    };
  }

  clock() { return Date.now(); }

  // Data saver on or off (see DATA_SAVER); it takes effect at the next start.
  setDataSaver(on) {
    const { sweepMs, ...options } = DATA_SAVER;
    this.dataSaver = !!on;
    this.options = on ? options : { ...FULL_OPTIONS };
    this.timing.sweepMs = on ? sweepMs : TIMING.sweepMs;
  }

  // ------------------------------------------------------------ lifecycle

  start() {
    if (this.running) return;
    this.running = true;
    this.abort = new AbortController();
    const signal = this.abort.signal;
    this.markets = new Map();
    this.events = new Map();
    this.marketEvent = new Map();
    this.marketsVersion++;
    this.analyzed = new Set();
    this.events_seen = 0;
    this.passes = 0;
    this.client = new PolyClient(signal);
    this.paper.client = this.client;
    this.status = { gamma: "connecting" };
    Object.assign(this.health, { marketsAt: 0, pricesAt: 0, streamAt: 0, startedAt: this.clock() });
    this.marketReconnectDelay = this.timing.reconnectMs;
    const loops = [
      this.eventsLoop(signal), this.booksLoop(signal), this.councilLoop(signal), this.paperLoop(signal),
    ];
    this.desk.start(signal);
    if (this.options.stream) this.startMarketStream(signal);
    else this.status.market_ws = "off (data saver: closing books read every 0.5 s)";
    this.started_at = this.clock();
    for (const p of loops) p.catch((e) => { if (!signal.aborted) { console.error("loop crashed", e); this.status.engine = `a loop crashed: ${e.message || e}`; } });
  }

  stop() {
    if (!this.running) return;
    this.running = false;
    this.abort.abort(new DOMException("stopped", "AbortError"));
    clearInterval(this.marketHeartbeat);
    clearTimeout(this.marketReconnectTimer);
    clearTimeout(this.councilTimer);
    this.marketSocket?.close();
    this.marketSocket = null;
    for (const k of Object.keys(this.status)) this.status[k] = "stopped";
    this.saveSignals();
  }

  setRules(patch) {
    if (patch.coins) patch = { ...patch, coins: { ...this.rules.coins, ...patch.coins } };
    Object.assign(this.rules, patch);
    this.saveRules();
    this._candidates = null;
  }
  saveRules() {
    this.rules.strategy_version = 6;
    storageSet("polyscan.rules", { ...Object.fromEntries(SAVED_RULES.map((k) => [k, this.rules[k]])), strategy_version: 6 });
  }
  coinOn(coin) { return !!(this.rules.coins && this.rules.coins[coin] !== false); }

  // ------------------------------------------------------------ data loops

  // Runs one pass of a loop. A pass that throws is recorded and the loop carries on after a short pause: a single bad
  // reply or a network outage must not stop the scan until the page is reloaded (a loop that threw used to stay
  // stopped, and the markets and prices stopped refreshing).
  async guard(name, signal, fn) {
    try { await fn(); return true; }
    catch (e) {
      if (signal.aborted) throw e;
      this.health.errors++;
      this.health.lastError = `${name}: ${String((e && e.message) || e).slice(0, 160)}`;
      this.health.lastErrorAt = this.clock();
      console.error(`polyscan: ${name} pass failed, retrying`, e);
      await sleep(this.timing.errorPauseMs, signal);
      return false;
    }
  }

  async eventsLoop(signal) {
    while (!signal.aborted) {
      let got = 0;
      await this.guard("markets", signal, async () => {
        // Events resolving within the fast window, soonest first (a buffer past the window so nothing is missed at the
        // edge as time passes). The map is kept across sweeps so order books survive; markets long ended are pruned
        // first, so the room they took is free for the windows that just opened.
        const aheadHours = this.options.sweepHours ?? this.rules.max_resolve_hours + 6;
        const endMaxIso = new Date(this.clock() + aheadHours * 3.6e6).toISOString();
        const seen = new Set();
        this.prune(null);
        for (let page = 0; page < 8 && !signal.aborted; page++) {
          const evs = await this.client.events(100, page * 100, endMaxIso, this.options.eventTag);
          if (!evs.length) break;
          got += evs.length;
          this.events_seen += this.absorb(evs, seen);
          this.status.gamma = `ok (${this.events.size} events, ${this.markets.size} markets in the fast window)`;
          await sleep(300, signal);
        }
        if (got) { this.health.marketsAt = this.clock(); this.health.sweeps++; this.prune(seen); }
        else this.status.gamma = `no answer${this.client.errors.gamma ? `: ${this.client.errors.gamma}` : ""} (retrying)`;
      });
      // after a sweep that brought nothing (network down, rate limit), try again soon rather than in 25 s
      await sleep(got ? this.timing.sweepMs : this.timing.sweepRetryMs, signal);
    }
  }

  absorb(evs, seen) {
    let n = 0;
    for (const ev of evs) {
      if (!ev.id) continue;
      if (!this.events.has(ev.id)) n++;
      this.events.set(ev.id, ev);
      for (const m of ev.markets) {
        if (!m.id) continue;
        seen && seen.add(m.id);
        const prev = this.markets.get(m.id);
        if (prev) { m.books = prev.books; m.booksAt = prev.booksAt; m.fastTape = prev.fastTape; }
        if (this.markets.size < WATCH_CAP || prev) { this.markets.set(m.id, m); this.marketsVersion++; }
        this.marketEvent.set(m.id, ev.id);
      }
    }
    return n;
  }

  // Drop markets that are clearly out of the fast window or long ended, unless the demo account holds them or an
  // open signal references them. Keeps books for everything still in play.
  prune(seen) {
    const now = this.clock(), maxH = this.rules.max_resolve_hours;
    const keep = new Set(Object.values(this.paper.acct.positions).map((p) => p.marketId));
    for (const s of this.signals) if (!s.outcome_result) keep.add(s.marketId);
    for (const [id, m] of this.markets) {
      if ((seen && seen.has(id)) || keep.has(id)) continue;
      const h = m.hoursToEnd(now);
      if (h == null || h < -1 || h > maxH + 12) {
        this.markets.delete(id); this.marketEvent.delete(id); this.marketsVersion++;
      }
    }
    // forget events with no remaining markets
    for (const [eid, ev] of this.events) if (!ev.markets.some((m) => this.markets.has(m.id))) this.events.delete(eid);
  }

  // The markets worth a council: the current and the next window of every coin that is switched on, soonest first.
  // The list depends on the market set, the coin switches and the clock; within one second only the clock moves, so
  // the passes of that second share one look at the markets.
  candidates(now) {
    const cap = this.options.candidateCap;
    const coinsKey = COIN_IDS.map((c) => (this.coinOn(c) ? 1 : 0)).join("");
    const c = this._candidates;
    if (c && c.version === this.marketsVersion && c.map === this.markets && c.size === this.markets.size && c.coins === coinsKey
      && c.cap === cap && now >= c.at && now - c.at < 1000) return c.list;
    const out = [];
    for (const m of this.markets.values()) {
      if (m.closed || !m.active || !m.enableOrderBook || !m.acceptingOrders) continue;
      const info = fiveMinute(m);
      if (!info || !this.coinOn(info.coin)) continue;
      if (info.endMs <= now || info.startMs > now + 300000) continue;
      out.push([info.endMs, COIN_IDS.indexOf(info.coin), m]);
    }
    out.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const list = out.slice(0, cap).map((x) => x[2]);
    this._candidates = { at: now, version: this.marketsVersion, map: this.markets, size: this.markets.size, coins: coinsKey, cap, list };
    return list;
  }

  // Windows that are running and will close within the entry window (plus a lead-in): judged on every update.
  closingMarkets(now) {
    const lead = (Number(this.rules.entry_window_s) + this.timing.preRollS) * 1000;
    return this.candidates(now).filter((m) => { const info = fiveMinute(m); return info.startMs <= now && info.endMs > now && info.endMs - now <= lead; });
  }

  // Complete (mutually-exclusive and exhaustive) negRisk events that resolve within the fast window — the arbitrage
  // universe, soonest first.
  arbEvents(limit = 30) {
    if (!this.options.arbitrage) return [];
    const now = this.clock(), maxH = this.rules.max_resolve_hours;
    return [...this.events.values()].filter((e) => {
      if (!e.complete || e.n < 2 || e.n > 20) return false;
      const hs = e.members.map((m) => m.hoursToEnd(now)).filter((h) => h != null);
      const h = hs.length ? Math.min(...hs) : null;
      return h != null && h > 0 && h <= maxH;
    }).sort((a, b) => b.vol24 - a.vol24).slice(0, limit);
  }

  // The live price stream. It is pinged every 10 s and answers each ping; a connection that has been quiet for 30 s
  // (it can stay "open" after a network change or a computer waking from sleep, while nothing comes through) or that
  // did not open within 15 s is dropped and a new one opened. Every failure schedules a retry, with a growing pause.
  startMarketStream(signal) {
    if (typeof WebSocket === "undefined") { this.status.market_ws = "unavailable"; return; }
    const retry = () => {
      if (signal.aborted) return;
      clearTimeout(this.marketReconnectTimer);
      this.marketReconnectTimer = setTimeout(connect, this.marketReconnectDelay);
      this.marketReconnectDelay = Math.min(this.marketReconnectDelay * 2, 10000);
    };
    const drop = (socket, why) => {
      if (this.marketSocket !== socket) return;
      this.marketSocket = null;
      this.marketStreamInitialized = false;
      this.subscribedAssets.clear();
      clearInterval(this.marketHeartbeat);
      socket.onopen = socket.onmessage = socket.onerror = socket.onclose = null;
      try { socket.close(); } catch { /* already gone */ }
      this.health.reconnects++;
      this.status.market_ws = signal.aborted ? "stopped" : `reconnecting (${why})`;
      retry();
    };
    const connect = () => {
      if (signal.aborted) return;
      let socket;
      try { socket = new WebSocket(MARKET_WS); }
      catch (e) { this.status.market_ws = `reconnecting (${String(e.message || e).slice(0, 60)})`; this.health.reconnects++; retry(); return; }
      this.marketSocket = socket;
      this.status.market_ws = "connecting";
      let heardAt = this.clock();
      const opening = setTimeout(() => { if (socket.readyState !== WebSocket.OPEN) drop(socket, "did not open"); }, this.timing.streamOpenMs);
      socket.onopen = () => {
        clearTimeout(opening);
        this.marketReconnectDelay = this.timing.reconnectMs;
        this.marketStreamInitialized = false;
        this.status.market_ws = "connected";
        heardAt = this.clock();
        this.syncMarketSubscriptions();
        clearInterval(this.marketHeartbeat);
        this.marketHeartbeat = setInterval(() => {
          if (this.clock() - heardAt > this.timing.streamQuietMs) { drop(socket, `quiet for ${Math.round((this.clock() - heardAt) / 1000)} s`); return; }
          try { if (socket.readyState === WebSocket.OPEN) socket.send("PING"); } catch { drop(socket, "send failed"); }
        }, this.timing.pingMs);
      };
      socket.onmessage = (event) => {
        heardAt = this.clock();
        this.health.streamAt = heardAt;
        if (event.data === "PONG") return;
        try {
          const messages = JSON.parse(event.data);
          for (const message of Array.isArray(messages) ? messages : [messages]) this.handleMarketMessage(message);
          this.status.market_ws = "live";
        } catch (e) { this.status.market_ws = `message error: ${e.message}`; }
      };
      socket.onerror = () => { this.status.market_ws = "reconnecting"; };
      socket.onclose = () => { clearTimeout(opening); drop(socket, "closed"); };
    };
    connect();
    signal.addEventListener("abort", () => {
      clearInterval(this.marketHeartbeat);
      clearTimeout(this.marketReconnectTimer);
      this.marketSocket?.close();
    }, { once: true });
  }

  syncMarketSubscriptions() {
    const socket = this.marketSocket;
    if (!socket || socket.readyState !== WebSocket.OPEN || !this.desiredAssetRefs.size) return;
    const desired = new Set(this.desiredAssetRefs.keys());
    if (!this.marketStreamInitialized) {
      socket.send(JSON.stringify({ assets_ids: [...desired], type: "market", custom_feature_enabled: true }));
      this.subscribedAssets = desired;
      this.marketStreamInitialized = true;
    } else {
      const added = [...desired].filter((id) => !this.subscribedAssets.has(id));
      const removed = [...this.subscribedAssets].filter((id) => !desired.has(id));
      if (added.length) socket.send(JSON.stringify({ assets_ids: added, operation: "subscribe" }));
      if (removed.length) socket.send(JSON.stringify({ assets_ids: removed, operation: "unsubscribe" }));
      this.subscribedAssets = desired;
    }
    this.marketAssetRefs = new Map(this.desiredAssetRefs);
  }

  handleMarketMessage(message) {
    const type = message.event_type || message.type;
    const payload = message.payload || message;
    const now = this.clock();
    const touched = new Set();
    const refFor = (id) => { const r = this.marketAssetRefs.get(String(id || "")); if (r) touched.add(r.market); return r; };
    // The venue's best bid / best ask is authoritative for the top of the book. Local levels better than it are stale:
    // trades take them without the stream always reporting each level's removal, and keeping them is what left a
    // bid above the ask between REST resyncs. A best price whose size is unknown stays as a zero-size level, so the
    // quote is right while fills skip it; zero-size levels that are no longer the best are dropped. Tradable prices
    // lie strictly between 0 and 1, so a best price of 0 or 1 is the venue saying that side of the book is empty.
    // Each side of a book is kept sorted best-first (every write below keeps it so), so once the stale levels are gone
    // the best price is either first or missing, and the side never needs sorting again.
    const setTop = (levels, price, descending) => {
      if (price == null || price === "") return;
      const value = Number(price);
      if (!Number.isFinite(value)) return;
      if (value <= 0 || value >= 1) { levels.length = 0; return; }
      const stale = (p) => descending ? p > value + 1e-9 : p < value - 1e-9;
      for (let i = levels.length - 1; i >= 0; i--) {
        if (stale(levels[i].price) || (levels[i].size === 0 && levels[i].price !== value)) levels.splice(i, 1);
      }
      if (levels.length && levels[0].price === value) return;
      if (levels.some((level) => level.price === value)) levels.sort((a, b) => descending ? b.price - a.price : a.price - b.price);
      else levels.unshift({ price: value, size: 0 });
    };
    const updateQuote = (ref, quote) => {
      const { market, side } = ref;
      market.books ||= { 0: { bids: [], asks: [] }, 1: { bids: [], asks: [] } };
      const book = market.books[side];
      setTop(book.bids, quote.best_bid ?? quote.bestBid, true);
      setTop(book.asks, quote.best_ask ?? quote.bestAsk, false);
      if (side === 0) {
        if (quote.best_bid != null || quote.bestBid != null) market.bestBidYes = Number(quote.best_bid ?? quote.bestBid);
        if (quote.best_ask != null || quote.bestAsk != null) market.bestAskYes = Number(quote.best_ask ?? quote.bestAsk);
      } else {
        if (quote.best_bid != null || quote.bestBid != null) market.bestBidNo = Number(quote.best_bid ?? quote.bestBid);
        if (quote.best_ask != null || quote.bestAsk != null) market.bestAskNo = Number(quote.best_ask ?? quote.bestAsk);
      }
      market.booksAt = now;
      market.recordFastSample(now);
    };
    const updateBook = (ref, raw) => {
      const { market, side } = ref;
      market.books ||= { 0: { bids: [], asks: [] }, 1: { bids: [], asks: [] } };
      const book = parseBook(raw);
      market.books[side] = book;
      if (side === 0) {
        if (book.bids.length) market.bestBidYes = book.bids[0].price;
        if (book.asks.length) market.bestAskYes = book.asks[0].price;
      } else {
        if (book.bids.length) market.bestBidNo = book.bids[0].price;
        if (book.asks.length) market.bestAskNo = book.asks[0].price;
      }
      market.booksAt = now;
      market.recordFastSample(now);
    };

    if (type === "book") {
      const ref = refFor(payload.asset_id ?? payload.assetId);
      if (ref) updateBook(ref, payload);
    } else if (type === "best_bid_ask") {
      const ref = refFor(payload.asset_id ?? payload.assetId);
      if (ref) updateQuote(ref, payload);
    } else if (type === "price_change") {
      for (const change of payload.price_changes || payload.priceChanges || []) {
        const ref = refFor(change.asset_id ?? change.assetId);
        if (!ref) continue;
        const { market, side } = ref;
        market.books ||= { 0: { bids: [], asks: [] }, 1: { bids: [], asks: [] } };
        const book = market.books[side];
        const isBid = String(change.side).toUpperCase() === "BUY";
        const levels = isBid ? book.bids : book.asks;
        const price = Number(change.price), size = Number(change.size);
        // the level is replaced or removed where it stands, keeping the side sorted best-first (no re-sort)
        if (Number.isFinite(price)) {
          let i = 0;
          while (i < levels.length && (isBid ? levels[i].price > price : levels[i].price < price)) i++;
          if (i < levels.length && levels[i].price === price) levels.splice(i, 1);
          if (size > 0) levels.splice(i, 0, { price, size });
        }
        updateQuote(ref, change);
      }
    } else if (type === "last_trade_price") {
      const ref = refFor(payload.asset_id ?? payload.assetId);
      if (ref && ref.side === 0) ref.market.lastTrade = Number(payload.price) || ref.market.lastTrade;
    } else if (type === "market_resolved") {
      const winnerId = String(payload.winning_asset_id ?? payload.winningAssetId ?? "");
      const ref = refFor(winnerId);
      const conditionId = String(payload.market ?? payload.condition_id ?? payload.conditionId ?? "");
      const markets = ref ? [ref.market] : [...this.markets.values()].filter((m) => m.conditionId === conditionId || m.id === conditionId);
      for (const market of markets) {
        const winner = market.tokenIds.indexOf(winnerId);
        if (winner < 0) continue;
        market.resolved = true; market.closed = true; market.active = false; market.winner = winner;
        this.marketsVersion++;
      }
      this.paper.monitor().catch((e) => console.error("stream settlement", e));
    } else return;
    this.health.pricesAt = now;

    // a take-profit or stop-loss fires on the first price update that reaches it, not on the next timer
    if (this.running) this.paper.checkExits();
    // a window about to close is judged on the very update, not on the next pass
    for (const market of touched) this.evaluateSoon(market);
    this.scheduleCouncilPass();
    this.changed();
  }

  // Something worth showing changed (a price on a watched market, a trade): tell the listener, if any.
  changed() { if (this.onChange) { try { this.onChange(); } catch { /* the listener's problem */ } } }

  // A Chainlink price arrived for this coin: judge its window if it is about to close.
  onPrice(coin) {
    if (!this.running) return;
    const now = this.clock();
    for (const m of this.closingMarkets(now)) if (fiveMinute(m).coin === coin) this.evaluateSoon(m);
    this.changed();
  }

  // Judge a market in its closing window now, or (if it was judged less than evalThrottleMs ago) once that time is up.
  evaluateSoon(m) {
    if (!this.running || !m) return;
    const info = fiveMinute(m);
    if (!info) return;
    const now = this.clock();
    if (info.endMs <= now || info.endMs - now > (Number(this.rules.entry_window_s) + 2) * 1000) return;
    const wait = this.timing.evalThrottleMs - (now - (this._evalAt.get(m.id) || 0));
    if (wait <= 0) { this._evalAt.set(m.id, now); this.evaluateMarket(m, now); return; }
    if (this._evalQueued.has(m.id)) return;
    this._evalQueued.add(m.id);
    setTimeout(() => {
      this._evalQueued.delete(m.id);
      if (!this.running) return;
      const live = this.markets.get(m.id) || m;
      this._evalAt.set(m.id, this.clock());
      this.evaluateMarket(live, this.clock());
    }, wait);
  }

  // One market's council, both sides, acting on what it finds: a strict signal is traded; with 5m paper explore on, the
  // best side with a positive edge is too. Used by the full pass and on every update of a closing market.
  evaluateMarket(m, now, tally = null, fresh = []) {
    if (!m.books) return null;
    let best = null;
    const close = this.closeContext(m, now);
    for (const side of [0, 1]) {
      const ctx = { now, side, event: null, tradeUsd: this.paper.tradeUsd(m, side), close, calib: this.desk.calibrator.byCoin };
      const verdict = runCouncil(m, ctx, this.rules);
      this.analyzed.add(m.id + ":" + side);
      if (tally) for (const v of verdict.votes) tally[v.agent][v.stance] = (tally[v.agent][v.stance] || 0) + 1;
      if (!best || compareRank(verdict, best) < 0) { best = verdict; verdict._ctx = ctx; }
      if (verdict.is_signal && this.cooldownOk(m, side, now) && !this.paper.windowUsed(m) && !this.paper.pending.has(`${m.id}:${side}`)) {
        const sig = buildSignal(m, verdict, this.rules, now, ctx);
        this.signals.push(sig); fresh.push(sig);
        this.paper.onSignal(sig, m).catch((e) => console.error("paper trade", e));
        this.changed();
      }
    }
    m.verdicts = { best };
    m.close = close;
    if (this.paper.settings.autoTrade && this.paper.settings.aggressive && best) this.autoExplore(new Map([[m.id, best]]), now, fresh);
    if (fresh.length) this.saveSignals();
    return best;
  }

  // The closing desk's view of a five-minute market for the council (stake and fill rules from the paper account).
  closeContext(m, now) {
    const s = this.paper.settings;
    return this.desk.context(m, now, {
      rules: this.rules, stake: (side) => this.paper.tradeUsd(m, side),
      share: s.strict ? s.fillShare : 1, maxSlippage: s.maxSlippage,
    });
  }

  scheduleCouncilPass() {
    if (!this.running || this.councilScheduled) return;
    this.councilScheduled = true;
    this.councilTimer = setTimeout(() => {
      this.councilScheduled = false;
      if (!this.running) return;
      try { this.councilPass(); } catch (e) { this.health.errors++; this.health.lastError = `council: ${String((e && e.message) || e).slice(0, 160)}`; this.health.lastErrorAt = this.clock(); }
    }, this.timing.councilDebounceMs);
  }

  async booksLoop(signal) {
    while (!signal.aborted) {
      await this.guard("order books", signal, () => this.booksPass());
      await sleep(250, signal);
    }
  }

  // One pass of the books loop. With the stream, every running window of a switched-on coin (and every held
  // position) is on it, so their books change the moment Polymarket's do; the next windows are read over REST every
  // 10 s, and everything is re-read every 30 s as a check. Without it (data saver), a window about to close is read
  // every 0.5 s and the rest every 10 s. Answers whether the stream is live.
  async booksPass() {
    const now = this.clock();
    const watch = new Map();
    for (const m of this.candidates(now)) watch.set(m.id, m);
    // held positions stay watched until they resolve, so their marks and exits use a live book
    for (const p of Object.values(this.paper.acct.positions)) {
      const m = this.markets.get(p.marketId);
      if (m) watch.set(m.id, m);
    }
    const closing = new Set(this.closingMarkets(now).map((m) => m.id));
    const held = new Set(Object.values(this.paper.acct.positions).map((p) => p.marketId));
    const streamed = new Set();
    const refs = new Map();
    if (this.options.stream) {
      for (const m of watch.values()) {
        const info = fiveMinute(m);
        if (!held.has(m.id) && !(info && info.startMs <= now + 15000)) continue; // running windows (and the next, 15 s early)
        streamed.add(m.id);
        if (m.tokenIds[0]) refs.set(m.tokenIds[0], { market: m, side: 0 });
        if (m.tokenIds[1]) refs.set(m.tokenIds[1], { market: m, side: 1 });
      }
    }
    this.desiredAssetRefs = refs;
    this.syncMarketSubscriptions();
    const socketLive = !!(this.marketSocket && this.marketSocket.readyState === WebSocket.OPEN && this.marketStreamInitialized);
    const due = [];
    for (const m of watch.values()) {
      const every = socketLive && streamed.has(m.id) ? 30000 : closing.has(m.id) ? this.timing.closingPollMs : this.timing.otherBooksMs;
      if (now - (m._restAt || 0) >= every) due.push(m);
    }
    if (due.length) {
      const tokenIds = due.flatMap((m) => m.tokenIds.filter(Boolean));
      for (const m of due) m._restAt = now;
      const books = await this.client.books(tokenIds.slice(0, 200));
      const t = this.clock();
      let attached = 0;
      for (const m of due) {
        if (!attachBooks(m, books, t)) continue;
        m.recordFastSample(t); attached++;
        if (closing.has(m.id)) this.evaluateSoon(m);
      }
      if (attached) { this.lastRestBooksAt = t; this.health.pricesAt = t; this.paper.checkExits(); this.changed(); }
    }
    const err = this.client.errors.clob;
    this.status.clob = err ? `error: ${err}` : `${socketLive ? `stream (${streamed.size} markets) + REST` : this.options.stream ? "REST (stream reconnecting)" : "REST: closing books every 0.5 s"} (${watch.size} markets)`;
    this.status.chainlink = this.desk.feed.status === "live" ? `live (${this.desk.feed.tapes.size} coins)` : this.desk.feed.status;
    return socketLive;
  }

  // ------------------------------------------------------------ council

  async councilLoop(signal) {
    while (!signal.aborted) {
      await this.guard("council", signal, () => { this.councilPass(); this.checkFreshness(); });
      await sleep(this.timing.councilMs, signal);
    }
  }

  // How fresh the data is, said in `status.data`; and if neither new markets nor new prices have come in for three
  // minutes while running, every feed is restarted (at most once in five minutes): whatever got stuck is replaced.
  checkFreshness() {
    const now = this.clock(), h = this.health;
    const age = (t) => (t ? Math.round((now - t) / 1000) : null);
    const since = Math.max(h.startedAt || 0, h.restartedAt || 0);
    const pricesAge = age(h.pricesAt), marketsAge = age(h.marketsAt);
    const fresh = (t, ms) => t && now - t < ms;
    if (fresh(h.pricesAt, 60000) && fresh(h.marketsAt, 120000)) this.status.data = `live (prices ${pricesAge} s, markets ${marketsAge} s old)`;
    else if (now - since < 60000) this.status.data = "connecting";
    else this.status.data = `stale (${pricesAge == null ? "no prices yet" : `prices ${pricesAge} s old`}, ${marketsAge == null ? "no markets yet" : `markets ${marketsAge} s old`}; retrying)`;
    const quietFor = now - Math.max(h.pricesAt || 0, h.marketsAt || 0, since);
    if (this.running && quietFor > this.timing.staleRestartMs && now - (h.restartedAt || 0) > this.timing.restartGapMs) {
      h.restarts++; h.restartedAt = now;
      h.lastError = `no new data for ${Math.round(quietFor / 1000)} s: feeds restarted`; h.lastErrorAt = now;
      setTimeout(() => { if (this.running) { this.stop(); this.start(); this.status.engine = `feeds restarted at ${new Date(now).toLocaleTimeString()} after ${Math.round(quietFor / 1000)} s without data`; } }, 0);
    }
  }

  councilPass() {
    const t0 = performance.now?.() ?? Date.now();
    const now = this.clock();
    const tally = Object.fromEntries(AGENTS.map((a) => [a.id, {}]));
    const addVotes = (vs) => { for (const v of vs) tally[v.agent][v.stance] = (tally[v.agent][v.stance] || 0) + 1; }; // risk-free sets
    const fresh = [];
    const best = new Map(); // marketId -> best verdict (for the leaderboard)

    // ---- arbitrage: one signal per complete event whose full set fills below $1
    for (const ev of this.arbEvents()) {
      if (!ev.members.every((mm) => mm.books)) continue;
      const arb = arbForEvent(ev);
      ev._arb = arb;
      if (!arb || arb.edge < this.rules.min_arb_edge) continue;
      const m = ev.members[0];
      const ctx = { now, side: 0, event: { augmented: ev.augmented, sumMid: ev.sumMid, n: ev.n, members: ev.members, siblings: ev.members.slice(1), arb }, tradeUsd: this.paper.tradeUsd() };
      const verdict = runCouncil(m, ctx, this.rules);
      addVotes(verdict.votes);
      if (verdict.is_signal && this.arbCooldownOk(ev.id, now)) {
        const sig = buildSignal(m, verdict, this.rules, now, ctx);
        this.signals.push(sig); fresh.push(sig);
        this.paper.onSignal(sig, m).catch((e) => console.error("paper arb", e));
      }
    }

    // ---- each watched five-minute market, each side (a market in its closing window is also judged on every update)
    for (const m of this.candidates(now)) {
      const v = this.evaluateMarket(m, now, tally, fresh);
      if (v) best.set(m.id, v);
    }
    // ---- learning: score the windows about to close, and settle the scores of those whose closing tick arrived
    this.desk.learn(this.closingMarkets(now), now);
    this._lastBest = best;
    this._arbEvents = this.arbEvents();
    this.settleSignals(now);
    this.agent_tally = tally;
    this.passes++;
    this.last_pass_ms = (performance.now?.() ?? Date.now()) - t0;
    if (fresh.length) this.saveSignals();
    return fresh;
  }

  // 5m paper explore: fill the demo up to its position cap with the best unvetoed picks below the strict signal bar,
  // still only inside the closing window (the clock agent vetoes anything else) and only with at least half the
  // minimum edge after fees. Exploratory, and logged as such: the strict signals stay the measured track record.
  autoExplore(best, now, fresh) {
    let open = this.paper.openCount(); // includes orders still travelling to the book
    if (open >= this.paper.settings.maxPositions) return;
    // with "require my real account" on: nothing to explore while that account could not trade at all
    if (this.paper.accountGate({ action: "buy", probe: true })) return;
    const picks = [...best.values()]
      .filter((v) => isFastCryptoMarket(this.markets.get(v.marketId)) && !v.vetoed_by.length && v.avoid_votes <= 2 && v.buy_votes >= 12 && v.edge >= this.rules.min_edge / 2)
      .sort(compareRank);
    const heldIds = [...Object.values(this.paper.acct.positions).map((p) => p.marketId), ...[...this.paper.pending].map((k) => k.split(":")[0])];
    const heldEvents = new Set(heldIds.map((id) => this.marketEvent.get(id)));
    for (const v of picks) {
      if (open >= this.paper.settings.maxPositions) break;
      const m = this.markets.get(v.marketId);
      if (!m || !m.books || !m.asks(v.side).length) continue;
      const key = `${m.id}:${v.side}`;
      if (this.paper.acct.positions[key] || this.paper.pending.has(key)) continue;
      if (this.paper.windowUsed(m)) continue; // one trade per market window: wait for the next window
      const evId = this.marketEvent.get(m.id);
      if (evId && heldEvents.has(evId)) continue; // diversify: one leg per event
      const ask = m.ask(v.side);
      const budget = this.paper.tradeUsd(m, v.side);
      if (!ask || budget / ask < (m.minOrder || 5)) continue;
      if (!this.cooldownOk(m, v.side, now)) continue;
      const ctx = v._ctx || { now, side: v.side, event: null, tradeUsd: this.paper.tradeUsd() };
      const sig = buildSignal(m, v, this.rules, now, ctx);
      sig.kind = "exploratory";
      this.signals.push(sig); fresh.push(sig);
      this.paper.onSignal(sig, m).catch((e) => console.error("explore", e));
      heldEvents.add(evId); open++;
      this.changed();
    }
  }

  arbCooldownOk(eventId, now) {
    const recent = this.signals.slice(-80).find((s) => s.kind === "arbitrage" && s.arb && s.eventId === eventId);
    return !recent || now - recent.created > 10 * 60 * 1000;
  }

  cooldownOk(m, side, now) {
    const recent = this.signals.slice(-60).find((s) => s.marketId === m.id && s.side === side);
    return !recent || now - recent.created > 20 * 60 * 1000;
  }

  // Score directional signals against the market's resolution once it closes.
  settleSignals(now) {
    let changed = false;
    for (const sig of this.signals) {
      if (sig.outcome_result || sig.kind === "arbitrage") continue;
      const m = this.markets.get(sig.marketId);
      const result = m && m.resolved ? scoreSignal(sig, m) : null;
      if (result) { sig.outcome_result = result; changed = true; }
    }
    if (changed) this.saveSignals();
  }

  async paperLoop(signal) {
    let lastEndedCheck = 0;
    while (!signal.aborted) {
      try { await this.paper.monitor(); } catch (e) { console.error("paper monitor", e); }
      if (this.clock() - lastEndedCheck >= 15000) {
        lastEndedCheck = this.clock();
        try { await this.refreshEnded(); } catch (e) { if (!signal.aborted) console.error("signal results", e); }
      }
      await sleep(500, signal);
    }
  }

  // A market leaves the scan once it closes (the scan only lists open markets), so a signal on a market the account
  // did not hold would never see its resolution. Re-read ended, unscored markets directly, a few at a time.
  async refreshEnded(batch = 5) {
    if (!this.client) return;
    const now = this.clock();
    this._endedCheckedAt ||= new Map();
    const ids = [...new Set(this.signals
      .filter((s) => !s.outcome_result && s.kind !== "arbitrage" && s.end_ms && s.end_ms <= now)
      .map((s) => s.marketId))]
      .filter((id) => !this.markets.get(id)?.resolved && now - (this._endedCheckedAt.get(id) || 0) >= 60000)
      .slice(0, batch);
    for (const id of ids) {
      this._endedCheckedAt.set(id, now);
      const fresh = await this.client.market(id);
      if (fresh) this.paper.onMarket(fresh);
    }
    this.settleSignals(now);
  }

  saveSignals() { storageSet("polyscan.signals", this.signals.slice(-300)); }

  // ------------------------------------------------------------ UI state

  trackRecord() {
    const scored = this.signals.filter((s) => s.outcome_result && s.kind !== "arbitrage");
    const wins = scored.filter((s) => s.outcome_result.status === "win").length;
    const nets = scored.map((s) => s.outcome_result.net_per_share);
    const arbs = this.signals.filter((s) => s.kind === "arbitrage").length;
    return {
      signals: this.signals.length, arbs, scored: scored.length, wins,
      win_rate: scored.length ? Math.round(1000 * wins / scored.length) / 10 : null,
      avg_net_per_share: nets.length ? Math.round(nets.reduce((a, b) => a + b, 0) / nets.length * 1000) / 1000 : null,
    };
  }

  // Each switched-on coin's running window as the desk sees it: the price to beat, the Chainlink price, the model's
  // and the market's odds, the edge of each side and what the engine is doing about it.
  closingView(now) {
    const running = new Map();
    for (const m of this.markets.values()) {
      const info = fiveMinute(m);
      if (info && info.startMs <= now && info.endMs > now && !running.has(info.coin)) running.set(info.coin, m);
    }
    const heldBy = new Map(Object.values(this.paper.acct.positions).map((p) => [p.marketId, p]));
    const rows = COIN_IDS.map((coin) => {
      const row = { coin, label: coinLabel(coin), on: this.coinOn(coin) };
      const m = running.get(coin);
      if (!m) { row.status = row.on ? "no window listed yet" : "off"; return row; }
      const c = this.closeContext(m, now);
      const sides = [0, 1].map((side) => c.sides[side]);
      const best = [0, 1].filter((i) => sides[i] && sides[i].edge != null).sort((a, b) => sides[b].edge - sides[a].edge)[0];
      Object.assign(row, {
        market_id: m.id, question: m.question, outcomes: m.outcomes, ends_in_s: Math.round(c.secsToEnd * 10) / 10, in_window: c.inWindow,
        strike: c.strike, strike_ticks: c.strikeTicks, spot: c.spot, spot_age_s: c.spotAgeMs == null ? null : Math.round(c.spotAgeMs / 100) / 10,
        known_s: c.known, avg_now: c.avgNow,
        gap_bp: (c.avgNow || c.spot) && c.strike ? Math.round(Math.log((c.avgNow || c.spot) / c.strike) * 1e5) / 10 : null,
        p_model: c.pModel, p_market: c.pMarket, p_up: c.pUp, sigma_bp: c.sigma ? Math.round(c.sigma * 1e5) / 10 : null,
        ask: [m.ask(0), m.ask(1)], edge: sides.map((x) => (x && x.edge != null ? x.edge : null)), cost: sides.map((x) => (x ? x.cost : null)),
        best_side: best ?? null, ok: c.ok, why: c.why,
      });
      const held = heldBy.get(m.id);
      const minEdge = this.rules.min_edge;
      if (!row.on) row.status = "off: not traded";
      else if (held) row.status = `holding ${m.outcomes[held.side]} (avg ${(held.avg * 100).toFixed(1)}¢)`;
      else if (this.paper.windowUsed(m)) row.status = "traded this window";
      else if (!c.ok) row.status = c.why;
      else if (c.secsToEnd > c.entryWindowS) row.status = `entries open in ${Math.ceil(c.secsToEnd - c.entryWindowS)} s`;
      else if (c.secsToEnd < c.entryStopS) row.status = "too late for an order";
      else if (best != null && sides[best].edge >= minEdge) row.status = `edge on ${m.outcomes[best]}: council deciding`;
      else row.status = "in the entry window: no edge";
      return row;
    });
    return { rows, desk: this.desk.summary(), entry_window_s: this.rules.entry_window_s, entry_stop_s: this.rules.entry_stop_s, min_edge: this.rules.min_edge };
  }

  marketRow(m, now) {
    const v = m.verdicts && m.verdicts.best;
    const side = v ? v.side : 0;
    const info = fiveMinute(m);
    return {
      coin: info ? info.coin : null, p: v ? v.p : null, cost: v ? v.cost : null,
      id: m.id, question: m.question, event: m.eventTitle, outcome: m.outcomes[side], image: m.image,
      outcomes: m.outcomes, ask0: m.ask(0), ask1: m.ask(1),
      side, ask: m.ask(side), mid: m.mid(side), spread: m.spreadOf(side),
      vol24: m.vol24, liq: m.liq, hours: m.hoursToEnd(now),
      buy_votes: v ? v.buy_votes : 0, avoid_votes: v ? v.avoid_votes : 0, vetoed: v ? v.vetoed_by.length > 0 : false,
      edge: v ? v.edge : null, arb: v ? v.arb : false, conviction: v ? v.conviction : 0,
      pending0: this.paper.pending.has(`${m.id}:0`), pending1: this.paper.pending.has(`${m.id}:1`),
      has_book: !!m.books, votes: v ? v.votes : [], veto_reason: v && v.vetoed_by.length ? (v.votes.find((x) => x.agent === v.vetoed_by[0]) || {}).reason : "",
    };
  }

  state() {
    const now = this.clock();
    const rows = this._lastBest ? [...this._lastBest.keys()].map((id) => this.markets.get(id)).filter(Boolean).map((m) => this.marketRow(m, now)) : [];
    rows.sort((a, b) => (b.arb - a.arb) || ((b.edge ?? -9) - (a.edge ?? -9)) || (b.buy_votes - a.buy_votes));
    let active = null; // the big card shows only vetted signals, never exploratory auto-buys
    for (let i = this.signals.length - 1; i >= 0; i--) {
      const s = this.signals[i];
      if (!s.outcome_result && s.kind !== "exploratory" && !(s.end_ms && s.end_ms <= now)) { active = { ...s }; const m = this.markets.get(s.marketId); if (m) { active.now_ask = m.ask(s.side); active.now_mid = m.mid(s.side); } break; }
    }
    return {
      running: this.running, now,
      uptime_s: this.running && this.started_at ? Math.floor((now - this.started_at) / 1000) : 0,
      stats: {
        events: this.events.size, markets: this.markets.size,
        with_books: [...this.markets.values()].filter((m) => m.books).length,
        analyzed: this.analyzed.size, passes: this.passes, last_pass_ms: Math.round(this.last_pass_ms * 10) / 10,
        complete_sets: this.arbEvents(99).length,
        max_resolve_hours: this.rules.max_resolve_hours,
      },
      sources: { ...this.status },
      rules: { ...this.rules },
      agents: AGENTS.map((a) => ({ id: a.id, name: a.name, group: a.group, description: a.description, veto: a.veto, tally: this.agent_tally[a.id] || {} })),
      candidates: rows.slice(0, 25),
      arb_watch: (this._arbEvents || []).map((ev) => {
        const arb = ev.members.every((mm) => mm.books) ? arbForEvent(ev) : null;
        const sumAsk = ev.members.reduce((s, mm) => s + (mm.ask(0) || 0), 0);
        return { id: ev.id, title: ev.title, outcomes: ev.n, vol24: ev.vol24, sum_ask: sumAsk, cost: arb ? arb.cost : null, edge: arb ? arb.edge : null, priced: !!arb };
      }).filter((x) => x.outcomes >= 2).sort((a, b) => (b.edge ?? -9) - (a.edge ?? -9)).slice(0, 10),
      active_signal: active,
      signals: this.signals.slice(-40).reverse(),
      track_record: this.trackRecord(),
      paper: this.livePaper(),
      closing: this.closingView(now),
    };
  }

  // Positions can only be traded while the scan is running: a stopped engine's books are frozen, and trading on
  // them would fill at stale prices.
  livePaper() {
    const snap = this.paper.snapshot();
    if (!this.running) for (const p of snap.positions) p.tradable = false;
    return snap;
  }

  // manual demo controls
  paperBuy(marketId, side) { if (!this.running) return; const m = this.markets.get(marketId); if (m) this.paper.buy(m, side, this.paper.tradeUsd(m, side)).catch((e) => console.error(e)); }
  paperSell(marketId, side) { if (!this.running) return; this.paper.sellAll(marketId, side, "manual").catch((e) => console.error(e)); }
  // Arm (price per share, 0–1) or clear (null) a position's take-profit. It can be set while the scan is stopped; it
  // only fires while the scan runs, because only then are the books live.
  paperTakeProfit(marketId, side, price) {
    const r = this.paper.setTakeProfit(this.paper.posKey(marketId, side), price);
    if (r.ok && price != null && this.running) this.paper.checkExits(marketId);
    return r;
  }
  paperStopLoss(marketId, side, price) {
    const r = this.paper.setStopLoss(this.paper.posKey(marketId, side), price);
    if (r.ok && price != null && this.running) this.paper.checkExits(marketId);
    return r;
  }
}
