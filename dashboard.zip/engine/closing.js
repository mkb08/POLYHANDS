// The closing-window desk for Polymarket's five-minute crypto markets ("Bitcoin Up or Down", eight coins, a new window
// every five minutes).
//
// How these markets settle, as measured (November 2026, 768 resolved markets): "Up" wins when the 60-second average
// of the Chainlink price at the window's close is at or above the 60-second average at its start. That rule matches
// 98.7% of the results with an exchange's prices standing in for Chainlink's (the rest are near-ties the stand-in
// cannot call); the price at the close against the price at the start matches only 91%. (Polymarket's own price API
// gives the plain Chainlink price at the start as a window's open; the settlement uses the averages.) Polymarket's
// live-data socket sends the Chainlink prices once a second for every coin, about 2 KB a second for all eight, and the
// desk keeps the last 20 minutes, so it computes both averages itself, second by second.
//
// So late in a window the question is nearly answered: with 10 s left, 50 of the closing average's 60 seconds are
// already in. The desk works out the chance of Up every time a price or the order book changes, blends it with what
// the market itself says (in proportion to how well each has predicted the results so far, learnt from every window
// it watches), and an entry is worth taking only when the book sells that side for less than the blended probability,
// after Polymarket's taker fee and the slippage of the stake.
//
// Nothing here places an order: the engine's council decides, and the paper account fills.

import { feePerShare, walkAsks } from "./core.js";

export const COINS = [
  { id: "btc", label: "BTC", name: "Bitcoin", chainlink: "btc/usd" },
  { id: "eth", label: "ETH", name: "Ethereum", chainlink: "eth/usd" },
  { id: "sol", label: "SOL", name: "Solana", chainlink: "sol/usd" },
  { id: "xrp", label: "XRP", name: "XRP", chainlink: "xrp/usd" },
  { id: "doge", label: "DOGE", name: "Dogecoin", chainlink: "doge/usd" },
  { id: "bnb", label: "BNB", name: "BNB", chainlink: "bnb/usd" },
  { id: "hype", label: "HYPE", name: "Hyperliquid", chainlink: "hype/usd" },
  { id: "zec", label: "ZEC", name: "Zcash", chainlink: "zec/usd" },
];
export const COIN_IDS = COINS.map((c) => c.id);
const COIN_BY_ID = Object.fromEntries(COINS.map((c) => [c.id, c]));
const COIN_BY_SYMBOL = Object.fromEntries(COINS.map((c) => [c.chainlink, c]));
export const coinLabel = (id) => (COIN_BY_ID[id] ? COIN_BY_ID[id].label : String(id || "").toUpperCase());

export const RTDS = "wss://ws-live-data.polymarket.com";
export const WINDOW_MS = 300000;

// A five-minute market's coin and window, from its slug ("btc-updown-5m-1793931300": the number is the window's
// start, in seconds). Null for anything else.
export function fiveMinute(m) {
  const x = String((m && m.slug) || "").toLowerCase().match(/^([a-z0-9]+)-updown-5m-(\d+)$/);
  if (!x || !COIN_BY_ID[x[1]]) return null;
  const startMs = Number(x[2]) * 1000;
  return { coin: x[1], startMs, endMs: (m && m.endMs) || startMs + WINDOW_MS };
}

// ------------------------------------------------------------------ the numbers

// The model's settings, chosen on 8 hours of recorded markets (768 windows, 8 coins) for the best log-score: the shape of
// the price moves over seconds (fat-tailed: a Student t with `nu` degrees of freedom), how fast the volatility estimate
// follows the market, and the starting blend of model and market before the desk has results of its own.
export const MODEL = {
  nu: 4,               // tail heaviness of price moves over a few seconds (lower = fatter tails, more caution near 0 and 1)
  fastHalfLifeS: 90,   // the quick volatility estimate forgets with this half-life ...
  slowHalfLifeS: 1800, // ... and the steady one with this one
  fastWeight: 0.4,     // the volatility used is this blend of the two ...
  sigmaScale: 1.35,    // ... times this: measured second-to-second moves understate how far the price wanders (best fit)
  minSamples: 30,      // seconds of prices needed before a coin's volatility is trusted
  maxSpotAgeMs: 4000,  // a Chainlink price older than this is too old to judge the close by
  jumpSigmas: 6,       // a one-second move this many times the usual size is a jump: the model is not trusted for 15 s
  prior: { a: 0.6, b: 0.4 }, // starting blend: logit(p) = a·logit(model) + b·logit(market), until results say otherwise
  priorWeight: 40,     // how many results the starting blend counts as
  checkpoints: [90, 60, 45, 30, 20, 10, 5], // seconds before the close at which each window is scored for learning
};

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const logit = (p) => { const q = clamp(p, 0.001, 0.999); return Math.log(q / (1 - q)); };
const sigmoid = (x) => 1 / (1 + Math.exp(-x));

// Lanczos log-gamma, the regularised incomplete beta (Numerical Recipes' continued fraction) and the Student t CDF.
function lgamma(x) {
  const c = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059,
    12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
  if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
  x -= 1;
  let a = c[0];
  const t = x + 7.5;
  for (let i = 1; i < 9; i++) a += c[i] / (x + i);
  return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
}
function betacf(a, b, x) {
  const TINY = 1e-300;
  const qab = a + b, qap = a + 1, qam = a - 1;
  let c = 1, d = 1 - (qab * x) / qap;
  if (Math.abs(d) < TINY) d = TINY;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= 300; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
    d = 1 + aa * d; if (Math.abs(d) < TINY) d = TINY;
    c = 1 + aa / c; if (Math.abs(c) < TINY) c = TINY;
    d = 1 / d; h *= d * c;
    aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
    d = 1 + aa * d; if (Math.abs(d) < TINY) d = TINY;
    c = 1 + aa / c; if (Math.abs(c) < TINY) c = TINY;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 3e-14) break;
  }
  return h;
}
function betai(a, b, x) {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  return x < (a + 1) / (a + b + 2) ? (bt * betacf(a, b, x)) / a : 1 - (bt * betacf(b, a, 1 - x)) / b;
}
export function normCdf(z) {
  // erfc with fractional error below 1.2e-7 (Numerical Recipes' erfcc)
  const x = Math.abs(z) / Math.SQRT2, t = 1 / (1 + 0.5 * x);
  const r = t * Math.exp(-x * x - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806
    + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
  return z >= 0 ? 1 - r / 2 : r / 2;
}
export function tCdf(t, nu) {
  if (!Number.isFinite(t)) return t > 0 ? 1 : 0;
  if (!(nu > 2) || nu > 300) return normCdf(t);
  const tail = 0.5 * betai(nu / 2, 0.5, nu / (nu + t * t));
  return t > 0 ? 1 - tail : tail;
}

// The chance the closing average ends at or above the price to beat (Up wins ties).
//
// The result is decided by two 60-second averages of the Chainlink price: the one ending at the window's close against
// the one ending at its start (the price to beat). Late in a window most of the closing average is already in: with
// 10 s left, 50 of its 60 seconds are known, and only the last 10 can still move it, each by at most a sixtieth of its
// own move. So the uncertainty left is small and exactly computable. With a random walk of `sigma` (log return per
// √second) from the latest price, the seconds still to come add to the average
//   inside the closing minute (r seconds left):  variance = (σ·S)² · r(r+1)(2r+1) / (6·60²)
//   before it (a seconds until it starts):       variance = (σ·S)² · (a + 61·121/360)
// and the moves are fat-tailed (a t distribution with the same variance).
//   strike     the price to beat (the opening average)
//   spot       the latest Chainlink price, at second `tickS`
//   endS       the window's close, in seconds
//   knownSum   the sum of the ticks already inside the closing average (seconds endS−59 … tickS), with knownN of them
export function settleProbability({ strike, spot, sigma, tickS, endS, knownSum = 0, knownN = 0, L = 60, nu = MODEL.nu }) {
  if (!(spot > 0) || !(strike > 0)) return null;
  let mean, variance;
  const r = endS - tickS;
  if (r <= 0) return knownN > 0 ? (knownSum / knownN >= strike ? 1 : 0) : null;
  if (!(sigma > 0)) return null;
  const v1 = (sigma * spot) ** 2;
  if (r < L) {
    const n = L - r; // seconds of the closing average already known
    const sum = knownN === n ? knownSum : knownN > 0 ? (knownSum / knownN) * n : spot * n;
    mean = (sum + r * spot) / L;
    variance = (v1 * r * (r + 1) * (2 * r + 1)) / (6 * L * L);
  } else {
    mean = spot;
    variance = v1 * (r - L + ((L + 1) * (2 * L + 1)) / (6 * L));
  }
  const z = (mean - strike) / Math.sqrt(variance);
  return { p: tCdf(z * Math.sqrt(nu / (nu - 2)), nu), z, mean, sd: Math.sqrt(variance) };
}

// ------------------------------------------------------------------ volatility, per coin

// How much the price moves per second, followed from the live ticks: a quick and a steady estimate (exponentially
// weighted, by half-life in seconds), and the time of the last jump.
export class VolTracker {
  constructor(model = MODEL) { this.model = model; this.fast = null; this.slow = null; this.n = 0; this.lastT = null; this.lastP = null; this.jumpAt = -Infinity; }
  add(tSec, price) {
    if (!(price > 0)) return;
    if (this.lastT != null) {
      const dt = tSec - this.lastT;
      if (dt <= 0) return;
      if (dt <= 30) {
        const r = Math.log(price / this.lastP);
        const v = (r * r) / dt; // variance per second
        if (this.slow != null && this.n >= this.model.minSamples && Math.abs(r) / Math.sqrt(dt) > this.model.jumpSigmas * Math.sqrt(this.slow)) this.jumpAt = tSec;
        const af = 1 - Math.pow(0.5, dt / this.model.fastHalfLifeS), as = 1 - Math.pow(0.5, dt / this.model.slowHalfLifeS);
        // the first minute is averaged evenly, so a quiet or wild first second does not set the level
        const warm = this.n < 60 ? 1 / (this.n + 1) : 0;
        this.fast = this.fast == null ? v : this.fast + Math.max(af, warm) * (v - this.fast);
        this.slow = this.slow == null ? v : this.slow + Math.max(as, warm) * (v - this.slow);
        this.n++;
      }
    }
    this.lastT = tSec; this.lastP = price;
  }
  ready() { return this.n >= this.model.minSamples && this.slow > 0; }
  sigma() {
    if (!this.ready()) return null;
    const w = this.model.fastWeight;
    return (this.model.sigmaScale || 1) * Math.sqrt(w * this.fast + (1 - w) * this.slow);
  }
  ratio() { return this.ready() ? Math.sqrt(this.fast / this.slow) : null; }
  jumpedWithin(tSec, secs = 15) { return tSec - this.jumpAt <= secs; }
}

// ------------------------------------------------------------------ the live Chainlink prices

// Polymarket's live-data socket, Chainlink topic: one price a second per coin. The tape keeps the last 20 minutes per
// coin, so any second of the current and previous windows can be looked up (the price to beat is the average of the
// minute up to the window's first second). A connection quiet for 15 s, or not open within 10 s, is replaced.
export class PriceFeed {
  constructor({ clock = () => Date.now(), WebSocketImpl = globalThis.WebSocket, keepMs = 20 * 60e3, model = MODEL } = {}) {
    this.clock = clock; this.WebSocketImpl = WebSocketImpl; this.keepMs = keepMs; this.model = model;
    this.tapes = new Map(); // coin -> { t: [ms], v: [price] }, in time order
    this.vols = new Map();  // coin -> VolTracker
    this.onTick = null;     // (coin, tMs, price) after each new price
    this.status = "off"; this.lastAt = 0; this.reconnects = 0; this.messages = 0;
    this.socket = null; this.timer = null; this.watch = null; this.delay = 500;
  }

  start(signal) {
    if (typeof this.WebSocketImpl !== "function") { this.status = "unavailable"; return; }
    const retry = () => {
      if (signal.aborted) return;
      clearTimeout(this.timer);
      this.timer = setTimeout(connect, this.delay);
      this.delay = Math.min(this.delay * 2, 10000);
    };
    const drop = (socket, why) => {
      if (this.socket !== socket) return;
      this.socket = null;
      clearInterval(this.watch);
      socket.onopen = socket.onmessage = socket.onerror = socket.onclose = null;
      try { socket.close(); } catch { /* gone */ }
      this.reconnects++;
      this.status = signal.aborted ? "stopped" : `reconnecting (${why})`;
      retry();
    };
    const connect = () => {
      if (signal.aborted) return;
      let socket;
      try { socket = new this.WebSocketImpl(RTDS); }
      catch (e) { this.status = `reconnecting (${String(e.message || e).slice(0, 60)})`; this.reconnects++; retry(); return; }
      this.socket = socket;
      this.status = "connecting";
      let heardAt = this.clock();
      const openBy = this.clock() + 10000;
      socket.onopen = () => {
        this.delay = 500;
        this.status = "connected";
        heardAt = this.clock();
        socket.send(JSON.stringify({ action: "subscribe", subscriptions: [{ topic: "crypto_prices_chainlink", type: "*", filters: "" }] }));
      };
      socket.onmessage = (event) => {
        heardAt = this.clock();
        const text = typeof event.data === "string" ? event.data : "";
        if (!text || text === "PONG" || text === "pong") return;
        try { this.handle(JSON.parse(text)); } catch { /* one bad message */ }
      };
      socket.onerror = () => { this.status = "reconnecting"; };
      socket.onclose = () => drop(socket, "closed");
      clearInterval(this.watch);
      this.watch = setInterval(() => {
        const open = socket.readyState === 1;
        if (!open && this.clock() > openBy) { drop(socket, "did not open"); return; }
        if (open && this.clock() - heardAt > 15000) { drop(socket, `quiet for ${Math.round((this.clock() - heardAt) / 1000)} s`); return; }
        try { if (open) socket.send("PING"); } catch { drop(socket, "send failed"); }
      }, 5000);
    };
    connect();
    signal.addEventListener("abort", () => this.stop(), { once: true });
  }

  stop() {
    clearTimeout(this.timer); clearInterval(this.watch);
    const s = this.socket; this.socket = null;
    if (s) { s.onopen = s.onmessage = s.onerror = s.onclose = null; try { s.close(); } catch { /* gone */ } }
    this.status = "stopped";
  }

  // One socket message: a price update (or a batch of them).
  handle(msg) {
    if (!msg || msg.topic !== "crypto_prices_chainlink") return;
    const p = msg.payload || {};
    const coin = COIN_BY_SYMBOL[String(p.symbol || "").toLowerCase()];
    if (!coin) return;
    const items = Array.isArray(p.data) ? p.data : [p];
    for (const it of items) this.add(coin.id, Number(it.timestamp), Number(it.value));
  }

  // Record one price (time in ms, on a whole second). Out-of-order or repeated seconds are ignored.
  add(coin, tMs, price) {
    if (!Number.isFinite(tMs) || !(price > 0)) return;
    let tape = this.tapes.get(coin);
    if (!tape) { tape = { t: [], v: [] }; this.tapes.set(coin, tape); this.vols.set(coin, new VolTracker(this.model)); }
    const last = tape.t.length ? tape.t[tape.t.length - 1] : -Infinity;
    if (tMs <= last) return;
    tape.t.push(tMs); tape.v.push(price);
    if (tape.t.length > 1500 || tape.t[0] < tMs - this.keepMs - 60000) {
      let cut = 0;
      while (cut < tape.t.length && tape.t[cut] < tMs - this.keepMs) cut++;
      if (cut) { tape.t.splice(0, cut); tape.v.splice(0, cut); }
    }
    this.vols.get(coin).add(tMs / 1000, price);
    this.lastAt = this.clock(); this.messages++;
    if (this.status !== "live") this.status = "live";
    if (this.onTick) this.onTick(coin, tMs, price);
  }

  latest(coin) {
    const tape = this.tapes.get(coin);
    return tape && tape.t.length ? { t: tape.t[tape.t.length - 1], v: tape.v[tape.v.length - 1] } : null;
  }
  // The price at exactly this second, or null if that tick never arrived.
  at(coin, tMs) {
    const tape = this.tapes.get(coin);
    if (!tape || !tape.t.length) return null;
    let lo = 0, hi = tape.t.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1, t = tape.t[mid];
      if (t === tMs) return tape.v[mid];
      if (t < tMs) lo = mid + 1; else hi = mid - 1;
    }
    return null;
  }
  // The price `secs` seconds before the latest tick (the nearest earlier tick), for short moves.
  before(coin, secs) {
    const tape = this.tapes.get(coin);
    if (!tape || tape.t.length < 2) return null;
    const want = tape.t[tape.t.length - 1] - secs * 1000;
    for (let i = tape.t.length - 1; i >= 0; i--) if (tape.t[i] <= want) return { t: tape.t[i], v: tape.v[i] };
    return null;
  }
  vol(coin) { return this.vols.get(coin) || null; }
}

// ------------------------------------------------------------------ learning from results

// Every watched window is scored at fixed seconds before its close: the model's probability of Up, the market's, and
// later the result. From those the desk fits how much to trust each (a logistic blend, held near the starting blend
// until there are enough results), and keeps the score of each: the Brier score, lower is better.
export class Calibrator {
  constructor({ load = () => null, save = () => {}, model = MODEL } = {}) {
    this.model = model; this.save = save;
    const s = load() || {};
    this.obs = Array.isArray(s.obs) ? s.obs.slice(-3000) : [];       // { c: coin, s: secsLeft, m: pModel, k: pMarket, y: 0|1, t }
    this.pending = Array.isArray(s.pending) ? s.pending.slice(-400) : []; // same, waiting for the result, with id and end
    this.fitted = null;
    this.refit();
  }
  persist() { this.save({ obs: this.obs.slice(-3000), pending: this.pending.slice(-400) }); }
  // One checkpoint of one window. `pMkt` may be null when the market had no two-sided book.
  observe({ id, coin, end, secsLeft, pModel, pMkt, t }) {
    if (pModel == null) return;
    this.pending.push({ id, c: coin, e: end, s: secsLeft, m: Math.round(pModel * 1e4) / 1e4, k: pMkt == null ? null : Math.round(pMkt * 1e4) / 1e4, t });
  }
  // The window's result is known: its checkpoints become results.
  resolve(id, up) {
    const done = this.pending.filter((p) => p.id === id);
    if (!done.length) return 0;
    this.pending = this.pending.filter((p) => p.id !== id);
    for (const p of done) this.obs.push({ c: p.c, s: p.s, m: p.m, k: p.k, y: up ? 1 : 0, t: p.t });
    if (this.obs.length > 3000) this.obs.splice(0, this.obs.length - 3000);
    this.refit();
    this.persist();
    return done.length;
  }
  // Pending checkpoints of windows that ended long ago (their result was never seen) are dropped.
  expire(now) {
    const before = this.pending.length;
    this.pending = this.pending.filter((p) => now - p.e < 30 * 60e3);
    if (this.pending.length !== before) this.persist();
  }
  // Maximum likelihood of logit(p) = a·logit(model) + b·logit(market), pulled toward the starting blend by a prior
  // worth `priorWeight` results (Newton steps on two numbers).
  refit() {
    const { prior, priorWeight } = this.model;
    const fitObs = this.obs.filter((o) => o.k != null); // a checkpoint with no market price says nothing about the blend
    const rows = fitObs.map((o) => ({ x1: logit(o.m), x2: logit(o.k), y: o.y }));
    let a = prior.a, b = prior.b;
    const lam = priorWeight / 4; // a result is worth about 1/4 in curvature at p = 0.5
    for (let it = 0; it < 25 && rows.length; it++) {
      let ga = -lam * (a - prior.a), gb = -lam * (b - prior.b), haa = -lam, hab = 0, hbb = -lam;
      for (const r of rows) {
        const p = sigmoid(a * r.x1 + b * r.x2), w = p * (1 - p), e = r.y - p;
        ga += e * r.x1; gb += e * r.x2; haa -= w * r.x1 * r.x1; hab -= w * r.x1 * r.x2; hbb -= w * r.x2 * r.x2;
      }
      const det = haa * hbb - hab * hab;
      if (!(Math.abs(det) > 1e-12)) break;
      const da = (hbb * ga - hab * gb) / det, db = (haa * gb - hab * ga) / det;
      a -= da; b -= db;
      a = clamp(a, -1, 3); b = clamp(b, -1, 3);
      if (Math.abs(da) + Math.abs(db) < 1e-6) break;
    }
    const brier = (f) => rows.length ? rows.reduce((s, r, i) => s + (f(r, i) - r.y) ** 2, 0) / rows.length : null;
    const withMkt = fitObs;
    this.fitted = {
      a, b, n: this.obs.length, pending: this.pending.length,
      brier_model: brier((r, i) => fitObs[i].m), brier_blend: brier((r) => sigmoid(a * r.x1 + b * r.x2)),
      brier_market: withMkt.length ? withMkt.reduce((s, o) => s + (o.k - o.y) ** 2, 0) / withMkt.length : null,
      brier_model_same: withMkt.length ? withMkt.reduce((s, o) => s + (o.m - o.y) ** 2, 0) / withMkt.length : null,
    };
    this.byCoin = {};
    for (const o of withMkt) {
      const c = (this.byCoin[o.c] ||= { n: 0, model: 0, market: 0 });
      c.n++; c.model += (o.m - o.y) ** 2; c.market += (o.k - o.y) ** 2;
    }
    for (const c of Object.values(this.byCoin)) { c.model /= c.n; c.market /= c.n; }
    return this.fitted;
  }
  // The probability of Up to trade on.
  blend(pModel, pMkt) {
    if (pModel == null) return null;
    if (pModel <= 0 || pModel >= 1) return pModel; // the close is already known
    const { a, b } = this.fitted || this.model.prior;
    return sigmoid(a * logit(pModel) + b * logit(pMkt == null ? pModel : pMkt));
  }
}

// ------------------------------------------------------------------ the desk

// The market's own chance of Up: the middle of the best Up quotes, where a missing Up quote is read from the Down book
// (buying Up at p is selling Down at 1 − p). With only one side quoted (late in a decided window nobody sells the
// winner), half a cent beyond it. Null with no quotes at all.
export function marketUp(m) {
  const ask = m.ask(0) ?? (m.bid(1) != null ? 1 - m.bid(1) : null);
  const bid = m.bid(0) ?? (m.ask(1) != null ? 1 - m.ask(1) : null);
  let p = null;
  if (ask != null && bid != null) p = (ask + bid) / 2;
  else if (bid != null) p = bid + 0.005;
  else if (ask != null) p = ask - 0.005;
  return p == null ? null : clamp(p, 0.001, 0.999);
}

export class ClosingDesk {
  constructor({ clock = () => Date.now(), WebSocketImpl, load, save, model = MODEL } = {}) {
    this.clock = clock; this.model = model;
    this.feed = new PriceFeed({ clock, WebSocketImpl, model });
    this.calibrator = new Calibrator({ load, save, model });
    this.strikes = new Map(); // marketId -> { value, n, end } once the opening average is complete
    this.strikeMiss = new Map(); // marketId -> seconds of the opening minute received, while too few
    this.scored = new Map();  // marketId -> { end, taken: Set of checkpoints }
  }
  start(signal) { this.feed.start(signal); }
  stop() { this.feed.stop(); }

  // The sum of the Chainlink prices at each whole second from `fromMs` to `toMs`. The feed does not resend a second it
  // missed (a short dropout leaves a hole), so a missing second is filled in on the straight line between the ticks
  // around it (or with the tick before it, at the end of the tape); null if more than `maxGaps` seconds are missing.
  sumSeconds(coin, fromMs, toMs, maxGaps = 15) {
    const tape = this.feed.tapes.get(coin);
    if (!tape || !tape.t.length || toMs < fromMs) return null;
    let i = 0, prev = null, prevT = null, sum = 0, have = 0, gaps = 0;
    while (i < tape.t.length && tape.t[i] < fromMs) { prev = tape.v[i]; prevT = tape.t[i]; i++; }
    for (let t = fromMs; t <= toMs; t += 1000) {
      while (i < tape.t.length && tape.t[i] < t) { prev = tape.v[i]; prevT = tape.t[i]; i++; }
      if (i < tape.t.length && tape.t[i] === t) { prev = tape.v[i]; prevT = t; i++; have++; sum += prev; continue; }
      if (prev == null || ++gaps > maxGaps) return null;
      sum += i < tape.t.length ? prev + ((tape.v[i] - prev) * (t - prevT)) / (tape.t[i] - prevT) : prev;
    }
    return { sum, n: have + gaps, ticks: have, gaps };
  }
  // The 60-second average ending at `atMs` (the seconds atMs−59 s … atMs), as Polymarket's settlement takes it.
  average(coin, atMs) {
    const r = this.sumSeconds(coin, atMs - 59000, atMs);
    return r ? { value: r.sum / r.n, n: r.ticks, gaps: r.gaps } : null;
  }

  // The price to beat: the 60-second average ending at the window's first second, from the feed's own ticks (the
  // engine must have been listening during that minute). Kept once complete.
  strike(m, info = fiveMinute(m)) {
    if (!info) return null;
    const have = this.strikes.get(m.id);
    if (have) return have;
    if (this.clock() < info.startMs) return null;
    // wait for the tick of the window's first second itself (it arrives about a second later), or 5 s at most
    const last = this.feed.latest(info.coin);
    if ((!last || last.t < info.startMs) && this.clock() < info.startMs + 5000) return null;
    const avg = this.average(info.coin, info.startMs);
    if (!avg) {
      // how much of the opening minute arrived, for the explanation
      const tape = this.feed.tapes.get(info.coin);
      this.strikeMiss.set(m.id, tape ? tape.t.filter((t) => t > info.startMs - 60000 && t <= info.startMs).length : 0);
      return null;
    }
    const s = { value: avg.value, n: avg.n, end: info.endMs };
    this.strikes.set(m.id, s);
    return s;
  }

  // The part of the closing average already in: the seconds from the closing minute's first to the latest tick.
  knownClosing(coin, endMs, tickMs) {
    if (tickMs < endMs - 59000) return { sum: 0, n: 0 };
    const r = this.sumSeconds(coin, endMs - 59000, Math.min(tickMs, endMs), 60);
    return r ? { sum: r.sum, n: r.n } : { sum: 0, n: 0 };
  }

  // Everything the council needs about one five-minute market right now: the price to beat and the latest price, the
  // model's probability of Up, the market's, the blend, and for each side what the stake would pay (walking the asks,
  // with Polymarket's taker fee) and the edge left over. `stake(side)` gives the stake in dollars, `share` the part of
  // each book level a paper order may take, `maxSlippage` the limit above the ask.
  context(m, now, { rules = {}, stake = () => 5, share = 1, maxSlippage = 0.01 } = {}) {
    const info = fiveMinute(m);
    if (!info) return null;
    const secsToEnd = (info.endMs - now) / 1000;
    const windowS = Number(rules.entry_window_s) || 60, stopS = Number(rules.entry_stop_s) || 4;
    const ctx = {
      coin: info.coin, label: coinLabel(info.coin), startMs: info.startMs, endMs: info.endMs, secsToEnd,
      entryWindowS: windowS, entryStopS: stopS, inWindow: secsToEnd <= windowS && secsToEnd >= stopS,
      started: now >= info.startMs, ok: false, why: "", strike: null, strikeTicks: null,
      spot: null, spotAt: null, spotAgeMs: null, sigma: null, volRatio: null, jump: false, move15: null,
      secsLeft: null, known: 0, avgNow: null, z: null, pModel: null, pMarket: null, pUp: null, sides: { 0: null, 1: null },
    };
    ctx.pMarket = marketUp(m);
    const s = this.strike(m, info);
    if (s) { ctx.strike = s.value; ctx.strikeTicks = s.n; }
    const last = this.feed.latest(info.coin);
    const vol = this.feed.vol(info.coin);
    if (last) {
      ctx.spot = last.v; ctx.spotAt = last.t; ctx.spotAgeMs = now - last.t;
      const back = this.feed.before(info.coin, 15);
      if (back) ctx.move15 = Math.log(last.v / back.v);
    }
    if (vol) { ctx.sigma = vol.sigma(); ctx.volRatio = vol.ratio(); ctx.jump = !!(last && vol.jumpedWithin(last.t / 1000, 15)); }
    if (!ctx.started) ctx.why = "window not started";
    else if (!last) ctx.why = "no Chainlink price yet";
    else if (ctx.strike == null) ctx.why = `price to beat unknown: ${this.strikeMiss.get(m.id) ?? 0} of the 60 s before this window were received (Polyscan was not listening then)`;
    else if (ctx.sigma == null) ctx.why = "measuring volatility (needs 30 s of prices)";
    else if (ctx.spotAgeMs > this.model.maxSpotAgeMs) ctx.why = `Chainlink price is ${Math.round(ctx.spotAgeMs / 1000)} s old`;
    else ctx.ok = true;
    if (last && ctx.strike != null && ctx.sigma != null) {
      const tickS = Math.round(last.t / 1000), endS = Math.round(info.endMs / 1000);
      const known = this.knownClosing(info.coin, info.endMs, last.t);
      const r = settleProbability({ strike: ctx.strike, spot: last.v, sigma: ctx.sigma, tickS, endS, knownSum: known.sum, knownN: known.n, nu: this.model.nu });
      ctx.secsLeft = Math.max(0, endS - tickS);
      ctx.known = known.n;
      if (r) {
        ctx.pModel = r.p; ctx.z = r.z ?? null; ctx.avgNow = r.mean ?? null;
        ctx.pUp = this.calibrator.blend(ctx.pModel, ctx.pMarket);
      }
    }
    for (const side of [0, 1]) {
      const asks = m.asks(side);
      const ask = m.ask(side);
      if (ask == null || !asks.length) continue;
      const budget = stake(side);
      const avail = share >= 1 ? asks : asks.map((l) => ({ price: l.price, size: l.size * share }));
      const fill = walkAsks(avail, budget, ask + maxSlippage);
      const vwap = fill.avgPrice;
      const fee = vwap != null ? feePerShare(m, vwap) : feePerShare(m, ask);
      const p = ctx.pUp == null ? null : side === 0 ? ctx.pUp : 1 - ctx.pUp;
      const cost = (vwap ?? ask) + fee;
      ctx.sides[side] = {
        ask, vwap, fee, cost, shares: fill.shares, filledUsd: fill.spent, budget, p,
        edge: p == null ? null : p - cost,
        // how far the closing average can still move against this side before it loses, in typical moves
        cushion: ctx.z == null ? null : side === 0 ? ctx.z : -ctx.z,
      };
    }
    return ctx;
  }

  // Score each closing market at the checkpoints (for learning), and settle the scores of windows whose closing minute
  // is complete: Up if its average is at or above the price to beat, exactly as Polymarket settles.
  learn(markets, now) {
    for (const m of markets) {
      const info = fiveMinute(m);
      if (!info) continue;
      const left = (info.endMs - now) / 1000;
      if (left <= 0 || left > this.model.checkpoints[0] + 1) continue;
      let rec = this.scored.get(m.id);
      for (const cp of this.model.checkpoints) {
        if (left > cp || left < cp - 3) continue; // a checkpoint is taken within 3 s after it passes, or not at all
        if (rec && rec.taken.has(cp)) continue;
        const ctx = this.context(m, now);
        if (!ctx || !ctx.ok || ctx.pModel == null) continue;
        if (!rec) { rec = { end: info.endMs, taken: new Set() }; this.scored.set(m.id, rec); }
        rec.taken.add(cp);
        this.calibrator.observe({ id: m.id, coin: info.coin, end: info.endMs, secsLeft: cp, pModel: ctx.pModel, pMkt: ctx.pMarket, t: now });
      }
    }
    let resolved = 0;
    const seen = new Set();
    for (const p of this.calibrator.pending) {
      if (seen.has(p.id) || now < p.e + 3000) continue; // the closing tick arrives about a second after the close
      seen.add(p.id);
      const s = this.strikes.get(p.id);
      const close = this.average(p.c, p.e);
      if (!s || !close) continue;
      resolved += this.calibrator.resolve(p.id, close.value >= s.value);
    }
    if (resolved || now % 60000 < 1000) this.calibrator.expire(now);
    for (const [id, r] of this.scored) if (now - r.end > 15 * 60e3) this.scored.delete(id);
    for (const [id, s] of this.strikes) if (now - s.end > 30 * 60e3) this.strikes.delete(id);
    if (this.strikeMiss.size > 100) this.strikeMiss.clear();
    return resolved;
  }

  // The settled result of a window from the tape (true = Up), or null while its closing minute is incomplete.
  outcome(m) {
    const info = fiveMinute(m);
    const s = info && this.strikes.get(m.id);
    if (!s || this.clock() < info.endMs + 3000) return null;
    const close = this.average(info.coin, info.endMs);
    return close ? close.value >= s.value : null;
  }

  summary() {
    const f = this.calibrator.fitted || {};
    return {
      feed: this.feed.status, feed_age_s: this.feed.lastAt ? Math.round((this.clock() - this.feed.lastAt) / 1000) : null, reconnects: this.feed.reconnects,
      results: f.n || 0, waiting: f.pending || 0, trust_model: f.a, trust_market: f.b,
      brier_model: f.brier_model_same, brier_market: f.brier_market, brier_blend: f.brier_blend,
      by_coin: this.calibrator.byCoin || {},
    };
  }
}
