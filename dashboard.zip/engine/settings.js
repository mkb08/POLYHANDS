// Every setting a person can change, described once. The website's settings panel and the extension's panel both draw
// themselves from configView() and send each change through applySetting(), so the two always offer the same choices
// with the same limits. Values are shown in the units a person thinks in (seconds, cents, %) and stored in the
// engine's own units (`scale` converts: stored = shown × scale). A "toggles" field is a row of on/off buttons, one
// per option; its value is an object (option -> true/false) and a change may name just the options that change.

import { COINS } from "./closing.js";

export const CONFIG = [
  {
    id: "markets", title: "Markets",
    fields: [
      { key: "coins", where: "rules", type: "toggles", label: "Markets to trade",
        options: COINS.map((c) => [c.id, c.label]),
        help: "Polymarket's five-minute Up or Down markets, one per coin. Only the coins switched on are watched and traded; switching one off stops new entries (open positions are kept)." },
    ],
  },
  {
    id: "closing", title: "Closing window",
    fields: [
      { key: "entry_window_s", where: "rules", type: "int", min: 5, max: 240, step: 1, unit: "s", label: "Enter in the last",
        help: "Entries are only made this many seconds or fewer before a window closes, when the Chainlink price against the price to beat nearly decides the result." },
      { key: "entry_stop_s", where: "rules", type: "int", min: 1, max: 60, step: 1, unit: "s", label: "Stop entering at",
        help: "No new entry this close to the end: the order would not reach the book before the window closes." },
      { key: "min_edge_c", store: "min_edge", scale: 0.01, where: "rules", type: "num", min: 0, max: 20, step: 0.5, unit: "¢ / share", label: "Min edge after fees",
        help: "How much the blended probability (model and market) must exceed what the stake pays per share, taker fee included, before an entry is a signal." },
      { key: "min_buy_votes", where: "rules", type: "int", min: 12, max: 25, step: 1, unit: "/ 25", label: "BUY votes for a signal",
        help: "Agents (of 25) that must vote BUY before an entry fires; the settlement model and the expected-value engine must be among them, and no safety agent may veto." },
    ],
  },
  {
    id: "trading", title: "Trading",
    fields: [
      { key: "autoTrade", where: "paper", type: "bool", label: "Auto-trade",
        help: "Let strict signals (and 5m paper explore, if on) open paper positions by themselves. Off: only your own buys." },
      { key: "aggressive", where: "paper", type: "bool", label: "5m paper explore",
        help: "Also take the council's best pick below the strict signal bar, still only in the closing window and only with at least half the minimum edge after fees. Exploratory: more trades, less certainty; useful for measuring." },
      { key: "realAccount", where: "paper", type: "bool", only: "extension", label: "Require my real Polymarket account",
        help: "Off (default): paper orders are paid from the demo balance, and each one must still be an order Polymarket would take (5-share minimum, fill-and-kill against the live book, market open, a price quoted by Polymarket's own panel). On: also only when your real account could place it right now: logged in, not blocked where you are, and enough Polymarket cash for the stake." },
      { key: "maxPositions", where: "paper", type: "int", min: 1, max: 10, step: 1, label: "Max open positions",
        help: "Positions held at once, counting orders still on their way. New picks wait while the account is full." },
      { key: "sizePct", where: "paper", type: "int", min: 1, max: 100, step: 1, unit: "% of start", label: "Stake per trade",
        help: "Share of the starting balance put on each trade, when no fixed stake is set. Polymarket's 5-share minimum can raise a small stake." },
      { key: "stakeUsd", where: "paper", type: "num", min: 0, max: 100000, step: 0.5, unit: "$", label: "Fixed stake per trade",
        help: "Put this many dollars on every trade instead of a share of the balance. 0 = off (the % above is used). Polymarket's 5-share minimum can raise a small stake; it never goes above the demo cash." },
      { key: "arbMaxUsd", where: "paper", type: "num", min: 1, max: 1000, step: 1, unit: "$", label: "Max per risk-free set",
        help: "Most money put into one complete outcome set." },
    ],
  },
  {
    id: "exits", title: "Exits",
    fields: [
      { key: "exitBeforeEndSec", store: "exitBeforeEndMs", scale: 1000, where: "paper", type: "int", min: 0, max: 120, step: 1, unit: "s", label: "Sell before the market ends",
        help: "Sell open positions this many seconds before the window closes, while polymarket.com still shows its trade panel (the hands can still do it). 0 = off (recommended: closing-window entries are held to the close)." },
      { key: "afterEnd", where: "paper", type: "select", label: "Once the market has ended",
        options: [["sell", "Sell to the waiting buyers right away"], ["wait", "Wait for the result"]],
        help: "After a window closes, Polymarket keeps taking orders until the result is settled: buyers wait on the winning side at about 99.9¢; the losing side has no buyers and pays $0 either way. polymarket.com hides its trade panel then, so this sale is an order sent straight to the exchange (as a trading bot would), not by hand." },
      { key: "autoTpPct", where: "paper", type: "int", min: 0, max: 900, step: 1, unit: "% profit", label: "Take profit on new positions",
        help: "Arm a take-profit on every new position at the price that returns this much after fees. 0 = off. Each position's TP button can change it." },
      { key: "autoSlPct", where: "paper", type: "int", min: 0, max: 95, step: 1, unit: "% loss", label: "Stop loss on new positions",
        help: "Arm a stop on every new position: sell once the bid falls to the price where it has lost this much after fees. 0 = off. Fast markets jump, so a stop can sell below its price." },
    ],
  },
  {
    id: "fills", title: "Fill realism",
    fields: [
      { key: "strict", where: "paper", type: "bool", label: "Strict fills",
        help: "Assume more friction than the feed shows: delay of 0.25–0.75 s with occasional spikes of up to 3 s more, half of each book level, arbitrage legs lost to faster traders, 2% of orders rejected, no fills on books older than 45 s, winnings one minute after resolution." },
      { key: "maxSlippageC", store: "maxSlippage", scale: 0.01, where: "paper", type: "num", min: 0, max: 10, step: 0.5, unit: "¢", label: "Price tolerance",
        help: "An order fills only within this many cents of the price it was sent at, or misses. Smaller is stricter." },
    ],
  },
];

const FIELDS = new Map(CONFIG.flatMap((g) => g.fields.map((f) => [f.key, f])));
const storeKey = (f) => f.store || f.key;
const round = (v, step) => { const k = Math.round(v / step) * step; return Number(k.toFixed(6)); };

function readStored(engine, f) {
  const src = f.where === "rules" ? engine.rules : engine.paper.settings;
  const v = src[storeKey(f)];
  if (f.type === "toggles") return Object.fromEntries(f.options.map(([k]) => [k, !!(v && v[k] !== false)]));
  if (f.type === "bool" || f.type === "select") return v;
  return v == null ? null : Number(((v) / (f.scale || 1)).toFixed(6));
}

// The settings as plain data (it crosses from the extension's background to its panel), with current values.
// `where` is "website" or "extension": a few settings only mean something in the extension.
export function configView(engine, where = "website") {
  return CONFIG.map((g) => ({
    id: g.id, title: g.title,
    fields: g.fields.filter((f) => !f.only || f.only === where).map((f) => ({
      key: f.key, type: f.type, label: f.label, help: f.help, unit: f.unit || "", min: f.min, max: f.max, step: f.step,
      options: f.options || null, value: readStored(engine, f),
    })),
  }));
}

// Validate and apply one change. Answers { ok, key, label, value (as shown), message } or { ok: false, message }.
export function applySetting(engine, key, raw) {
  const f = FIELDS.get(key);
  if (!f) return { ok: false, message: `unknown setting "${key}"` };
  let value, message = "";
  const truthy = (x) => x === true || x === "true" || x === "on" || x === 1 || x === "1";
  if (f.type === "toggles") {
    // an object of option -> on/off (only the options that change are needed), or "btc:on" / "btc:off"
    let patch = raw;
    if (typeof raw === "string") { const [k, v] = raw.split(":"); patch = { [k]: truthy(v) }; }
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) return { ok: false, label: f.label, message: `${f.label}: send which ones to switch on or off` };
    const known = new Set(f.options.map(([k]) => k));
    const bad = Object.keys(patch).filter((k) => !known.has(k));
    if (bad.length) return { ok: false, label: f.label, message: `${f.label}: "${bad.join('", "')}" is not one of the choices` };
    value = { ...readStored(engine, f), ...Object.fromEntries(Object.entries(patch).map(([k, v]) => [k, truthy(v)])) };
    if (!Object.values(value).some(Boolean)) message = "every market is off: nothing will be traded";
    engine.setRules({ [storeKey(f)]: value });
    return { ok: true, key, label: f.label, value, shown: describe(f, value), message };
  }
  if (f.type === "bool") value = truthy(raw);
  else if (f.type === "select") {
    if (!f.options.some(([v]) => v === raw)) return { ok: false, label: f.label, message: `${f.label}: "${raw}" is not one of the choices` };
    value = raw;
  } else {
    const n = typeof raw === "number" ? raw : parseFloat(String(raw).replace(",", "."));
    if (!Number.isFinite(n)) return { ok: false, label: f.label, message: `${f.label}: type a number` };
    value = round(Math.min(f.max, Math.max(f.min, n)), f.step || 1);
    if (f.type === "int") value = Math.round(value);
    if (value !== n) message = `kept within ${f.min}–${f.max}${f.unit ? " " + f.unit : ""}${f.step && f.step !== 1 ? ` in steps of ${f.step}` : ""}`;
  }
  const stored = f.type === "bool" || f.type === "select" ? value : Number((value * (f.scale || 1)).toFixed(6));
  if (f.where === "rules") engine.setRules({ [storeKey(f)]: stored });
  else engine.paper.setSettings({ [storeKey(f)]: stored });
  return { ok: true, key, label: f.label, value, shown: describe(f, value), message };
}

function describe(f, v) {
  if (f.type === "toggles") { const on = f.options.filter(([k]) => v[k]).map(([, t]) => t); return on.length === f.options.length ? `all ${on.length} on` : on.length ? on.join(", ") : "none"; }
  if (f.type === "bool") return v ? "on" : "off";
  if (f.type === "select") return (f.options.find(([k]) => k === v) || [v, v])[1];
  if ((f.key === "autoTpPct" || f.key === "autoSlPct" || f.key === "exitBeforeEndSec") && v === 0) return "off";
  if (f.key === "stakeUsd" && v === 0) return "off (the % of the start balance is used)";
  if (f.unit === "$") return `$${v}`;
  return `${v}${f.unit ? (f.unit.startsWith("%") || ["¢", "s", "h"].includes(f.unit) ? "" : " ") + f.unit : ""}`;
}

// One line describing the current setup, for places with no room for the whole panel.
export function configSummary(engine) {
  const s = engine.paper.settings, r = engine.rules;
  const coins = CONFIG[0].fields[0].options.filter(([k]) => !r.coins || r.coins[k] !== false).map(([, t]) => t);
  const parts = [
    coins.length === CONFIG[0].fields[0].options.length ? "all 8 coins" : coins.length ? coins.join("/") : "no coins on",
    `enter in the last ${r.entry_window_s} s`,
    `max ${s.maxPositions} positions`, s.stakeUsd > 0 ? `stake $${s.stakeUsd} fixed` : `stake ${s.sizePct}%`,
    s.exitBeforeEndMs > 0 ? `sell ${Math.round(s.exitBeforeEndMs / 1000)} s before the end` : "no early exit",
    s.afterEnd === "sell" ? "after the end: sell at once" : "after the end: wait for the result",
    s.autoTpPct > 0 ? `TP +${s.autoTpPct}%` : "TP off", s.autoSlPct > 0 ? `SL −${s.autoSlPct}%` : "SL off",
    s.strict ? "strict fills" : "plain fills",
  ];
  return parts.join(" · ");
}
