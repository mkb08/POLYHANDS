// The market model, the 25 analysis agents, the council, and the money math for Polymarket.
//
// Polymarket is a prediction market, not a memecoin exchange. Every market is binary at the token level: two
// outcome tokens whose shares each pay exactly $1 if that outcome wins and $0 if it loses. Multi-outcome questions
// ("who wins the election") are groups of such binary markets inside one event. Prices live in [0,1] and read as
// probabilities. So the honest, mathematically grounded edges are:
//   - Dutch-book arbitrage: on a complete, mutually-exclusive-and-exhaustive outcome set, buying one share of every
//     outcome costs Σ(ask) and pays exactly $1 at resolution. If Σ(ask + fee) < 1 that is risk-free profit.
//   - Binary complement arbitrage: within one market, YES ask + NO ask + fees < 1 is the same thing.
//   - Documented price biases (favorite-longshot) and order-flow, which are weak and clearly labelled speculative.
// There is no pretense of forecasting elections better than the crowd; the market mid IS the crowd's forecast.
//
// The engine now trades only Polymarket's five-minute crypto markets, and only in the last seconds before each window
// closes, where the result is nearly decided by a measurable quantity (the Chainlink price against the price to
// beat). The closing desk (closing.js) works out the probability and the cost of each side; it reaches the agents as
// `ctx.close`. Several agents read it; the rest keep checking that the market can be traded well at all.

export const BUY = "BUY", HOLD = "HOLD", AVOID = "AVOID", ABSTAIN = "ABSTAIN";

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };
export const usd = (x) => x == null ? "–" : (x < 0 ? "-$" : "$") + Math.abs(x).toFixed(2);
export const cents = (p) => p == null ? "–" : `${(p * 100).toFixed(1)}¢`;
const pctStr = (x) => `${x >= 0 ? "+" : ""}${(x * 100).toFixed(1)}%`;
const pct = (p) => `${(p * 100).toFixed(p > 0.99 || p < 0.01 ? 1 : 0)}%`;
const fmtBp = (bp) => `${bp >= 0 ? "+" : "−"}${Math.abs(bp) >= 10 ? (Math.abs(bp) / 100).toFixed(2) + "%" : Math.abs(bp).toFixed(1) + " bp"}`;
const fmtSecs = (s) => (s >= 90 ? `${Math.round(s / 60)} min` : `${Math.round(s)} s`);
const fmtPrice = (x) => (x >= 1000 ? x.toLocaleString("en-US", { maximumFractionDigits: 2 }) : x >= 1 ? x.toFixed(4) : x.toPrecision(5));

// ------------------------------------------------------------------ fee math
// Taker fee per market schedule: rate * shares * (p*(1-p))^exponent. Makers pay no fee.
// Fee parameters come from market metadata; the venue rounds each fee to 5 decimal places.
export function feePerShare(m, price) {
  if (!m || !m.feesEnabled || !(m.feeRate > 0)) return 0;
  const base = price * (1 - price);
  return m.feeRate * Math.pow(base, m.feeExp || 1);
}

export function feeForFill(m, price, shares) {
  const fee = feePerShare(m, price) * shares;
  return Math.round(fee * 1e5) / 1e5;
}

// Walk a sorted ask ladder (ascending price) spending up to `usdBudget`, never paying above `limitPrice`.
export function walkAsks(asks, usdBudget, limitPrice = Infinity, shareDecimals = null) {
  let spent = 0, shares = 0;
  const levels = [];
  const scale = shareDecimals == null ? 1 : 10 ** shareDecimals;
  for (const lvl of asks || []) {
    const p = num(lvl.price), avail = num(lvl.size);
    if (p <= 0 || avail <= 0) continue;
    if (p > limitPrice + 1e-9) break;
    const canSpend = usdBudget - spent;
    if (canSpend <= 1e-9) break;
    const wantShares = canSpend / p;
    let take = Math.min(wantShares, avail);
    if (shareDecimals != null) take = Math.floor((take + 1e-9) * scale) / scale;
    if (take <= 0) break;
    shares += take; spent += take * p;
    levels.push({ price: p, shares: take });
    if (take < avail) break;
  }
  return { shares, spent, avgPrice: shares > 0 ? spent / shares : null, filled: spent, levels };
}

// Walk a sorted ask ladder buying up to `shares`, never paying above `limitPrice`.
export function walkAsksShares(asks, shares, limitPrice = Infinity) {
  let left = shares, spent = 0, bought = 0;
  const levels = [];
  for (const lvl of asks || []) {
    const p = num(lvl.price), avail = num(lvl.size);
    if (p <= 0 || avail <= 0) continue;
    if (p > limitPrice + 1e-9 || left <= 1e-9) break;
    const take = Math.min(left, avail);
    spent += take * p; bought += take; left -= take;
    levels.push({ price: p, shares: take });
  }
  return { shares: bought, spent, avgPrice: bought > 0 ? spent / bought : null, levels };
}

// Walk a bid ladder (descending price) selling `shares`, never selling below `limitPrice`. Proceeds before fees.
export function walkBids(bids, shares, limitPrice = 0, shareDecimals = null) {
  let left = shares, proceeds = 0, sold = 0;
  const levels = [];
  const scale = shareDecimals == null ? 1 : 10 ** shareDecimals;
  for (const lvl of bids || []) {
    const p = num(lvl.price), avail = num(lvl.size);
    if (p <= 0 || avail <= 0 || left <= 1e-9) continue;
    if (p < limitPrice - 1e-9) break;
    let take = Math.min(left, avail);
    if (shareDecimals != null) take = Math.floor((take + 1e-9) * scale) / scale;
    if (take <= 0) break;
    proceeds += take * p; sold += take; left -= take;
    levels.push({ price: p, shares: take });
  }
  return { proceeds, sold, avgPrice: sold > 0 ? proceeds / sold : null, remaining: left, levels };
}

// ------------------------------------------------------------------ market model

export class Market {
  constructor(f) {
    Object.assign(this, {
      id: "", question: "", slug: "", conditionId: "", eventId: "", eventTitle: "", groupTitle: "",
      outcomes: ["Yes", "No"], tokenIds: ["", ""], image: "",
      // prices are for outcome 0 (the YES side); outcome 1 is the complement
      yesMid: null, bestBidYes: null, bestAskYes: null, bestBidNo: null, bestAskNo: null,
      lastTrade: null, spread: null,
      vol24: 0, liq: 0, chg1h: 0, chg24h: 0, openInterest: 0,
      endMs: null, createdMs: null,
      feeRate: 0, feesEnabled: false, feeExp: 1, tickSize: 0.001, minOrder: 5,
      version: null, executionMeta: { 0: null, 1: null },
      negRisk: false, negRiskAugmented: false, enableOrderBook: true, acceptingOrders: true,
      active: true, closed: false, restricted: false, umaStatuses: [],
      resolutionSource: "", description: "",
      // filled in for candidates
      books: null,        // {0:{bids,asks},1:{bids,asks}} from the CLOB
      history: null,      // [{t,p}] for outcome 0
      booksAt: 0, historyAt: 0,
      fastTape: [],       // recent CLOB mid snapshots for minute-scale momentum
      // resolution (when closed)
      resolved: false, winner: null, // index 0/1 of the winning outcome
      // per-pass council output, keyed by side
      verdicts: {},
    }, f);
  }

  // Once a side's book is loaded it is the only source: an empty side has no quote. Falling back to the cached Gamma
  // or stream best price there mixed an old price with the live book and could put the bid above the ask.
  ask(side) {
    const book = this.books && this.books[side];
    if (book) return book.asks && book.asks.length ? num(book.asks[0].price) : null;
    return side === 0 ? this.bestAskYes : this.bestAskNo;
  }
  bid(side) {
    const book = this.books && this.books[side];
    if (book) return book.bids && book.bids.length ? num(book.bids[0].price) : null;
    return side === 0 ? this.bestBidYes : this.bestBidNo;
  }
  asks(side) { return this.books && this.books[side] ? this.books[side].asks || [] : []; }
  bids(side) { return this.books && this.books[side] ? this.books[side].bids || [] : []; }
  mid(side) {
    const a = this.ask(side), b = this.bid(side);
    if (a != null && b != null) return (a + b) / 2;
    if (side === 0 && this.yesMid != null) return this.yesMid;
    if (side === 1 && this.yesMid != null) return 1 - this.yesMid;
    return null;
  }
  spreadOf(side) {
    const a = this.ask(side), b = this.bid(side);
    return a != null && b != null ? a - b : (this.spread != null ? this.spread : null);
  }
  hoursToEnd(now) { return this.endMs ? (this.endMs - now) / 3.6e6 : null; }
  depthUsd(side) { // $ of asks within 3 cents of best
    const asks = this.asks(side);
    if (!asks.length) return null;
    const best = num(asks[0].price);
    let d = 0;
    for (const l of asks) { if (num(l.price) > best + 0.03) break; d += num(l.price) * num(l.size); }
    return d;
  }
  bookImbalance() { // (bid$ - ask$)/(bid$+ask$) within 5c of mid, outcome 0
    const asks = this.asks(0), bids = this.bids(0);
    if (!asks.length || !bids.length) return null;
    const m = this.mid(0);
    const sum = (ls, lo, hi) => ls.reduce((s, l) => (num(l.price) >= lo && num(l.price) <= hi ? s + num(l.price) * num(l.size) : s), 0);
    const bd = sum(bids, m - 0.05, m), ad = sum(asks, m, m + 0.05);
    return bd + ad > 0 ? (bd - ad) / (bd + ad) : null;
  }

  // The tape is in time order and kept in place: samples older than two minutes leave from the front. (It used to be
  // copied on every price update, a large share of the engine's work on a busy stream.)
  recordFastSample(now) {
    const mid = this.mid(0);
    if (mid == null) return;
    const tape = this.fastTape || (this.fastTape = []);
    const last = tape[tape.length - 1];
    if (last && now - last.t < 250) return;
    let old = 0;
    while (old < tape.length && now - tape[old].t > 120000) old++;
    if (old) tape.splice(0, old);
    tape.push({ t: now, mid });
    if (tape.length > 512) tape.shift();
  }
}

const FAST_CRYPTO_TICKERS = new Set(["btc", "eth", "sol", "xrp", "doge", "bnb", "hype", "zec"]);
export function isFastCryptoMarket(m) {
  const match = String(m && m.slug || "").toLowerCase().match(/^([a-z0-9]+)-updown-5m-\d+$/);
  return !!match && FAST_CRYPTO_TICKERS.has(match[1]);
}

// Recent probability movement is useful as an entry-timing hypothesis only when the book snapshots are fresh.
export function shortHorizonMove(m, now, windowMs = 30000) {
  const tape = (m.fastTape || []).filter((sample) => sample.t <= now && now - sample.t <= 60000);
  const latest = tape[tape.length - 1];
  if (!latest || now - latest.t > 15000 || tape.length < 3) return null;
  const minSpan = windowMs * 0.67, maxSpan = windowMs * 1.5;
  const baselineIndex = tape.slice(0, -2).findLastIndex((sample) => {
    const span = latest.t - sample.t;
    return span >= minSpan && span <= maxSpan;
  });
  if (baselineIndex < 0) return null;
  const path = tape.slice(baselineIndex);
  const baseline = path[0];
  const move = latest.mid - baseline.mid;
  if (path.length < 3 || Math.abs(move) < 0.005) return null;
  const direction = Math.sign(move);
  const aligned = path.slice(1).filter((sample, index) => {
    return (sample.mid - path[index].mid) * direction >= -0.002;
  }).length;
  return {
    move,
    consistency: aligned / (path.length - 1),
    spanMs: latest.t - baseline.t,
    samples: path.length,
    ageMs: now - latest.t,
  };
}

// ------------------------------------------------------------------ agents

const strengthClamp = (x) => Math.round(clamp(Number.isFinite(x) ? x : 0, 0, 1) * 1000) / 1000;
export const AGENTS = [];
function agent(id, name, group, description, veto, fn) { AGENTS.push({ id, name, group, description, veto, fn }); }

// ctx: { now, side, event (siblings + arb), tradeUsd, close (closing-desk view of a five-minute market, or null), calib }
export function vote(a, m, ctx) {
  let stance, strength, reason;
  try { [stance, strength, reason] = a.fn(m, ctx); }
  catch (e) { [stance, strength, reason] = [ABSTAIN, 0, `error: ${e.message}`]; }
  return { agent: a.id, stance, strength: strengthClamp(strength), reason };
}

const sideName = (m, ctx) => m.outcomes[ctx.side] || (ctx.side === 0 ? "Yes" : "No");

// ---- tradeability (veto group): can this be traded well at all?

agent("tradable", "Market Status Sentinel", "tradeability",
  "The market must be open, accepting orders, on the order book, and not in dispute.", true, (m) => {
    if (m.closed || !m.active) return [AVOID, 1, "market is closed or inactive"];
    if (!m.enableOrderBook) return [AVOID, 1, "no order book (not CLOB-traded)"];
    if (!m.acceptingOrders) return [AVOID, 1, "not accepting orders right now"];
    if (m.restricted) return [AVOID, 1, "market is geo-restricted"];
    if ((m.umaStatuses || []).some((s) => s && s !== "" && s !== "proposed")) return [AVOID, 0.9, `in UMA resolution (${m.umaStatuses.join(",")})`];
    return [BUY, 0.5, "open and accepting orders"];
  });

agent("spread", "Spread Sentinel", "tradeability",
  "The bid/ask spread must be tight, or you start the trade already down.", true, (m, ctx) => {
    const s = m.spreadOf(ctx.side);
    if (s == null) return [ABSTAIN, 0, "no two-sided quote yet"];
    if (s > 0.08) return [AVOID, 0.9, `spread ${cents(s)}: too wide to trade`];
    if (s > 0.04) return [HOLD, 0.3, `spread ${cents(s)}: wide`];
    return [BUY, 0.5 + 0.5 * (1 - s / 0.04), `spread ${cents(s)}`];
  });

agent("depth", "Order Book Depth Auditor", "tradeability",
  "There must be enough size near the ask to fill the intended order.", true, (m, ctx) => {
    const d = m.depthUsd(ctx.side);
    const need = ctx.tradeUsd || 20;
    if (d == null) return [ABSTAIN, 0, "order book not loaded"];
    if (d < need) return [AVOID, 0.9, `only ${usd(d)} of asks within 3¢: can't fill ${usd(need)}`];
    if (d < need * 3) return [HOLD, 0.3, `thin book: ${usd(d)} within 3¢`];
    return [BUY, 0.5 + 0.4 * clamp(d / (need * 10), 0, 1), `${usd(d)} of asks within 3¢`];
  });

agent("liquidity", "Liquidity Floor", "tradeability",
  "Total market liquidity and recent volume must clear a floor. A five-minute market is too young for a 24h volume, so there the money on its book counts.", true, (m, ctx) => {
    if (ctx.close) {
      if (m.liq < 300) return [AVOID, 0.8, `thin market: ${usd(m.liq)} on the book`];
      return [m.liq < 1000 ? HOLD : BUY, m.liq < 1000 ? 0.3 : 0.5 + 0.3 * clamp(Math.log10(m.liq / 1000), 0, 1), `${usd(m.liq)} on the book`];
    }
    if (m.liq < 2000 && m.vol24 < 2000) return [AVOID, 0.8, `thin market: ${usd(m.liq)} liquidity, ${usd(m.vol24)} 24h volume`];
    if (m.liq < 10000) return [HOLD, 0.3, `${usd(m.liq)} liquidity`];
    return [BUY, 0.5 + 0.3 * clamp(Math.log10(m.liq / 10000), 0, 1), `${usd(m.liq)} liquidity, ${usd(m.vol24)} 24h`];
  });

agent("closing_clock", "Closing Window Clock", "tradeability",
  "Five-minute crypto markets only, and only in the last seconds before the window closes, when the result is nearly decided; not so late that an order would arrive after the close.", true, (m, ctx) => {
    const c = ctx.close;
    if (!c) return [AVOID, 1, "not a five-minute crypto market"];
    if (!c.started) return [AVOID, 1, "this window has not started"];
    const left = c.secsToEnd;
    if (left <= 0) return [AVOID, 1, "the window has closed"];
    if (left > c.entryWindowS) return [AVOID, 0.6, `closes in ${fmtSecs(left)}: entries start in the last ${c.entryWindowS} s`];
    if (left < c.entryStopS) return [AVOID, 0.8, `${left.toFixed(1)} s to the close: an order would not arrive in time`];
    return [BUY, 0.5 + 0.4 * (1 - left / c.entryWindowS), `${left.toFixed(0)} s to the close: inside the entry window`];
  });

agent("extreme_price", "Extreme Price Guard", "tradeability",
  "Near 0 or 1 the upside is tiny and the tail risk is lopsided. In the closing seconds, entries are kept between 15¢ and 95¢: beyond them the result hangs on the model's rarest cases.", true, (m, ctx) => {
    const a = m.ask(ctx.side);
    if (a == null) return [ABSTAIN, 0, "no ask"];
    if (ctx.close && a >= 0.95) return [AVOID, 0.8, `ask ${cents(a)}: at most ${cents(1 - a)} of upside against the whole stake`];
    if (ctx.close && a < 0.15) return [AVOID, 0.7, `ask ${cents(a)}: a longshot, decided by the model's rarest cases`];
    if (a >= 0.97) return [AVOID, 0.8, `ask ${cents(a)}: at most ${cents(1 - a)} of upside, full downside`];
    if (a <= 0.03) return [HOLD, 0.3, `ask ${cents(a)}: deep longshot`];
    if (a >= 0.9) return [HOLD, 0.3, `ask ${cents(a)}: little room up`];
    return [BUY, 0.5, `ask ${cents(a)}: room both ways`];
  });

agent("settle_data", "Settlement Data Sentinel", "tradeability",
  "The Chainlink price, the price to beat and the order book must all be fresh before the close can be judged; no trading for 15 s after a price jump.", true, (m, ctx) => {
    const c = ctx.close;
    if (!c) return [ABSTAIN, 0, "no closing data for this market"];
    if (!c.ok) return [AVOID, 0.9, c.why || "closing data not ready"];
    if (c.jump) return [AVOID, 0.8, "Chainlink price jumped in the last 15 s: waiting for it to settle"];
    const bookAge = m.booksAt ? ctx.now - m.booksAt : Infinity;
    if (bookAge > 3000) return [AVOID, 0.8, `order book ${Number.isFinite(bookAge) ? (bookAge / 1000).toFixed(1) + " s" : "never"} old`];
    return [BUY, 0.6, `Chainlink price ${(c.spotAgeMs / 1000).toFixed(1)} s old, book ${(bookAge / 1000).toFixed(1)} s old`];
  });

agent("entry_cost", "Entry Cost Auditor", "tradeability",
  "Walks the ask ladder for the actual stake: it must fill Polymarket's 5-share minimum within the price limit, without paying much above the best ask.", true, (m, ctx) => {
    const x = ctx.close && ctx.close.sides[ctx.side];
    if (!x) return [ABSTAIN, 0, "no asks on this side"];
    const min = m.minOrder || 5;
    if (!(x.shares >= min - 1e-9)) return [AVOID, 0.9, `the book fills only ${(x.shares || 0).toFixed(1)} shares within 1¢ of the ask (minimum ${min})`];
    const slip = x.vwap - x.ask;
    if (slip > 0.02) return [AVOID, 0.8, `the stake would pay ${cents(x.vwap)} on average, ${cents(slip)} above the ask`];
    return [BUY, 0.5 + 0.3 * clamp(1 - slip / 0.02, 0, 1), `stake fills at ${cents(x.vwap)} avg + ${cents(x.fee)} fee per share`];
  });

// ---- mispricing / value group: is there an edge?

// The core of the closing desk: the chance this side wins from the Chainlink price, the price to beat, the time left
// and how far the price moves in that time, against what this side costs.
agent("settlement_model", "Settlement Model", "value",
  "From the live Chainlink price against the price to beat, the seconds left and the coin's measured volatility (fat-tailed moves): the chance this side wins, against its all-in cost.", false, (m, ctx) => {
    const c = ctx.close, x = c && c.sides[ctx.side];
    if (!c || c.pModel == null) return [ABSTAIN, 0, c ? c.why || "model not ready" : "not a five-minute crypto market"];
    if (!x) return [ABSTAIN, 0, "no asks on this side"];
    const p = ctx.side === 0 ? c.pModel : 1 - c.pModel;
    const edge = p - x.cost;
    const where = `closing average heading ${fmtBp(Math.log((c.avgNow || c.spot) / c.strike) * 1e4)} vs the price to beat, ${c.known}/60 s in`;
    if (edge >= 0.01) return [BUY, clamp(0.55 + edge * 6, 0.55, 1), `${where}: ${sideName(m, ctx)} ${pct(p)} vs cost ${cents(x.cost)}`];
    if (edge < -0.02) return [AVOID, 0.6, `${where}: ${sideName(m, ctx)} ${pct(p)}, below its cost ${cents(x.cost)}`];
    return [HOLD, 0.3, `${where}: ${sideName(m, ctx)} ${pct(p)} ≈ cost ${cents(x.cost)}`];
  });

agent("complement", "Binary Complement Agent", "value",
  "Within one market, YES ask + NO ask + fees below $1 is a risk-free pair.", false, (m) => {
    const ay = m.ask(0), an = m.ask(1);
    if (ay == null || an == null) return [ABSTAIN, 0, "need both sides' asks"];
    const cost = ay + an + feePerShare(m, ay) + feePerShare(m, an);
    if (cost < 0.995) return [BUY, clamp(0.7 + (1 - cost) * 10, 0.7, 1), `YES+NO cost ${usd(cost)} < $1: risk-free ${((1 - cost) * 100).toFixed(1)}%`];
    if (cost > 1.03) return [HOLD, 0.2, `YES+NO cost ${usd(cost)}: normal overround`];
    return [HOLD, 0.3, `YES+NO cost ${usd(cost)}`];
  });

agent("cushion", "Cushion Gauge", "value",
  "How far the price can still move against this side before it loses, in typical moves for the time left. A side that is already losing needs a reversal.", false, (m, ctx) => {
    const x = ctx.close && ctx.close.sides[ctx.side];
    if (!x || x.cushion == null) return [ABSTAIN, 0, "model not ready"];
    const k = x.cushion;
    if (k >= 1) return [BUY, clamp(0.5 + (k - 1) * 0.15, 0.5, 0.9), `${k.toFixed(1)} typical moves of cushion before it loses`];
    if (k >= 0.4) return [HOLD, 0.35, `${k.toFixed(1)} typical moves of cushion: close call`];
    if (k > -1) return [HOLD, 0.25, k >= 0 ? "on the line: a coin flip" : `behind by ${(-k).toFixed(1)} typical moves`];
    return [AVOID, 0.45, `behind by ${(-k).toFixed(1)} typical moves: needs a reversal`];
  });

agent("favorite_longshot", "Favorite-Longshot Bias", "value",
  "A documented bias: longshots are overbet and favorites underbet. Mild, price-dependent.", false, (m, ctx) => {
    const a = m.ask(ctx.side);
    if (a == null) return [ABSTAIN, 0, "no ask"];
    if (a >= 0.55 && a <= 0.9) return [BUY, 0.4 + 0.3 * ((a - 0.55) / 0.35), `${cents(a)} favorite: the underbet side historically`];
    if (a <= 0.15) return [AVOID, 0.4, `${cents(a)} longshot: overbet historically`];
    return [HOLD, 0.25, `${cents(a)}: no clear bias`];
  });

agent("market_lag", "Market Lag Detector", "value",
  "The edge on these markets comes from the order book lagging the Chainlink price. A market far more sure than the model the other way may know something the feed has not shown yet.", false, (m, ctx) => {
    const c = ctx.close;
    if (!c || c.pModel == null || c.pMarket == null) return [ABSTAIN, 0, "model or market price not ready"];
    const pm = ctx.side === 0 ? c.pModel : 1 - c.pModel, pk = ctx.side === 0 ? c.pMarket : 1 - c.pMarket;
    const gap = pm - pk;
    if (gap >= 0.03) return [BUY, clamp(0.5 + gap * 4, 0.5, 0.9), `the market (${pct(pk)}) lags the Chainlink price (${pct(pm)}) by ${cents(gap)}`];
    if (gap <= -0.12) return [AVOID, 0.5, `the market (${pct(pk)}) is far surer than the model (${pct(pm)}) against this side`];
    return [HOLD, 0.3, `market ${pct(pk)} vs model ${pct(pm)}`];
  });

// ---- momentum / flow group

agent("chainlink_momentum", "Chainlink Momentum", "flow",
  "The last 15 seconds of the Chainlink price, in typical moves: is it running toward this side or away from it?", false, (m, ctx) => {
    const c = ctx.close;
    if (!c || c.move15 == null || !(c.sigma > 0)) return [ABSTAIN, 0, "not enough recent prices"];
    const k = (c.move15 / (c.sigma * Math.sqrt(15))) * (ctx.side === 0 ? 1 : -1);
    if (k >= 1) return [BUY, clamp(0.5 + (k - 1) * 0.15, 0.5, 0.8), `price ran ${k.toFixed(1)} typical moves this way in 15 s`];
    if (k <= -2) return [AVOID, 0.4, `price ran ${(-k).toFixed(1)} typical moves against this side in 15 s`];
    return [HOLD, 0.3, `15-second move ${k >= 0 ? "+" : ""}${k.toFixed(1)} typical moves`];
  });

agent("trend", "Fast Trend Confirmation", "flow",
  "Checks persistence over a longer fresh 45-second path.", false, (m, ctx) => {
    const fast = shortHorizonMove(m, ctx.now, 45000);
    if (!fast) return [ABSTAIN, 0, "not enough fresh snapshots for a 45-second trend"];
    const sideMove = fast.move * (ctx.side === 0 ? 1 : -1);
    if (fast.consistency >= 0.7 && sideMove >= 0.025) return [BUY, clamp(0.5 + sideMove * 3, 0.5, 0.85), `persistent ${cents(sideMove)} move over ${Math.round(fast.spanMs / 1000)}s`];
    if (fast.consistency >= 0.7 && sideMove <= -0.025) return [AVOID, 0.45, `persistent move against this side (${cents(-sideMove)})`];
    return [HOLD, 0.3, `no persistent 45-second trend (${cents(sideMove)})`];
  });

agent("vol_regime", "Volatility Regime", "flow",
  "Compares the last minute's volatility with the last quarter hour's. In a sudden storm the model's odds are less certain.", false, (m, ctx) => {
    const c = ctx.close;
    if (!c || c.volRatio == null) return [ABSTAIN, 0, "measuring volatility"];
    if (c.volRatio > 2.5) return [AVOID, 0.5, `volatility ${c.volRatio.toFixed(1)}× its usual level: odds less certain`];
    if (c.volRatio > 1.6) return [HOLD, 0.3, `volatility ${c.volRatio.toFixed(1)}× usual`];
    return [BUY, 0.45, `steady volatility (${c.volRatio.toFixed(1)}× usual)`];
  });

agent("book_imbalance", "Book Imbalance Tracker", "flow",
  "More resting bids than asks near the mid is buy pressure for outcome 0.", false, (m, ctx) => {
    const imb = m.bookImbalance();
    if (imb == null) return [ABSTAIN, 0, "order book not loaded"];
    const sideImb = ctx.side === 0 ? imb : -imb;
    if (sideImb > 0.3) return [BUY, clamp(0.5 + sideImb / 2, 0.5, 0.8), `book leans to this side (${(sideImb * 100).toFixed(0)}% imbalance)`];
    if (sideImb < -0.3) return [ctx.close ? HOLD : AVOID, 0.4, `book leans against (${(sideImb * 100).toFixed(0)}%)`];
    return [HOLD, 0.3, `balanced book (${(sideImb * 100).toFixed(0)}%)`];
  });

agent("bid_support", "Bid Support Agent", "flow",
  "Resting bids below the ask are the demand you would exit into; thin bids mean you are stuck.", false, (m, ctx) => {
    const bids = m.bids(ctx.side);
    if (!bids.length) return [ABSTAIN, 0, "order book not loaded"];
    const need = ctx.tradeUsd || 20;
    const top = bids[0].price;
    let support = 0;
    for (const l of bids) { if (l.price < top - 0.05) break; support += l.price * l.size; }
    if (support < need) return [HOLD, 0.3, `only ${usd(support)} of bids within 5¢ to exit into`];
    return [BUY, 0.4 + 0.3 * clamp(support / (need * 8), 0, 1), `${usd(support)} of bid support within 5¢`];
  });

agent("strike_check", "Price-to-Beat Auditor", "flow",
  "The price to beat is the 60-second average of the Chainlink price before the window opened, computed from the feed's own ticks: it is trusted only when (nearly) every one of those seconds arrived.", false, (m, ctx) => {
    const c = ctx.close;
    if (!c || c.strike == null) return [ABSTAIN, 0, "price to beat not known yet"];
    if (c.strikeTicks >= 58) return [BUY, 0.55, `price to beat ${fmtPrice(c.strike)} from ${c.strikeTicks} of the opening minute's 60 seconds`];
    if (c.strikeTicks >= 50) return [HOLD, 0.35, `price to beat ${fmtPrice(c.strike)} from ${c.strikeTicks} of 60 seconds (the feed dropped some; filled in)`];
    return [AVOID, 0.5, `price to beat estimated: only ${c.strikeTicks} of the opening minute's 60 seconds arrived`];
  });

// ---- structure / context group

agent("resolution_clarity", "Resolution Clarity", "structure",
  "A clear resolution source and no dispute make the payoff trustworthy.", false, (m) => {
    if (!m.resolutionSource && !(m.description && m.description.length > 40)) return [HOLD, 0.25, "no stated resolution source"];
    if ((m.umaStatuses || []).some((s) => s === "disputed")) return [AVOID, 0.6, "resolution disputed"];
    return [BUY, 0.45, m.resolutionSource ? "clear resolution source" : "resolution described"];
  });

agent("calibration_coach", "Calibration Coach", "structure",
  "Scores the model against the market on every window it watches, per coin. Where the market's own odds have predicted results better, it advises against overruling them.", false, (m, ctx) => {
    const c = ctx.close, b = c && ctx.calib && ctx.calib[c.coin];
    if (!c) return [ABSTAIN, 0, "not a five-minute crypto market"];
    if (!b || b.n < 60) return [HOLD, 0.3, `learning ${c.label}: ${b ? b.n : 0} of 60 scored checkpoints so far`];
    const better = (b.market - b.model) / b.market;
    if (better >= 0.02) return [BUY, clamp(0.5 + better * 2, 0.5, 0.85), `model beat the market on ${c.label} (Brier ${b.model.toFixed(3)} vs ${b.market.toFixed(3)}, ${b.n} checkpoints)`];
    if (better <= -0.1) return [AVOID, 0.5, `the market beat the model on ${c.label} (Brier ${b.market.toFixed(3)} vs ${b.model.toFixed(3)})`];
    return [HOLD, 0.35, `model and market about even on ${c.label} (${b.n} checkpoints)`];
  });

agent("time_value", "Quick-Turnaround Agent", "structure",
  "A fast market frees your capital quickly and gives a real result within hours.", false, (m, ctx) => {
    const h = m.hoursToEnd(ctx.now);
    if (h == null || h < 0) return [ABSTAIN, 0, "no valid end date"];
    const maxH = (ctx.rules && ctx.rules.max_resolve_hours) || 24;
    if (h <= maxH) return [BUY, 0.5 + 0.3 * (1 - h / maxH), `resolves in ${h < 1 ? (h * 60).toFixed(0) + " min" : h.toFixed(1) + "h"}: quick turnaround`];
    return [HOLD, 0.25, `${(h / 24).toFixed(1)}d: ties up capital`];
  });

agent("price_level", "Probability Band", "structure",
  "Mid-range probabilities have two-way risk and the most room to be wrong about.", false, (m, ctx) => {
    const a = m.ask(ctx.side);
    if (a == null) return [ABSTAIN, 0, "no ask"];
    if (a >= 0.3 && a <= 0.75) return [BUY, 0.5, `${cents(a)}: balanced odds`];
    if (a > 0.9 || a < 0.1) return [HOLD, 0.25, `${cents(a)}: lopsided`];
    return [BUY, 0.4, `${cents(a)}`];
  });

agent("category_fit", "Category & Fee Fit", "structure",
  "Zero-fee categories (geopolitics, many politics) and maker-friendly books keep more of any edge.", false, (m, ctx) => {
    const fee = feePerShare(m, m.ask(ctx.side) || 0.5);
    if (!m.feesEnabled || m.feeRate === 0) return [BUY, 0.55, "zero trading fees on this market"];
    if (fee > 0.015) return [HOLD, 0.25, `${cents(fee)}/share taker fee`];
    return [BUY, 0.4, `${cents(fee)}/share taker fee`];
  });

// The aggregator: net expected value of buying this side, after fees. On a five-minute market in its closing window
// it uses the desk's blended probability (model and market, weighted by their record) and the stake's real fill price.
agent("expected_value", "Expected Value Engine", "value",
  "The blended probability of this side (model and market, weighted by how well each has predicted results) minus what the stake pays per share, fee included.", false, (m, ctx) => {
    const c = ctx.close;
    if (c) {
      const x = c.sides[ctx.side];
      if (c.pUp == null || !x) return [ABSTAIN, 0, c.why || "no probability or no asks yet"];
      if (x.edge > 0.005) return [BUY, clamp(0.5 + x.edge * 10, 0.5, 0.95), `net edge ${cents(x.edge)}/share: ${pct(x.p)} vs ${cents(x.cost)} all-in`];
      if (x.edge < -0.02) return [AVOID, 0.5, `negative edge ${cents(x.edge)}/share after fees`];
      return [HOLD, 0.3, `edge ${cents(x.edge)}/share: thin`];
    }
    const a = m.ask(ctx.side);
    if (a == null) return [ABSTAIN, 0, "no ask"];
    const continuation = estimateContinuation(m, ctx);
    const fee = feePerShare(m, a);
    const edge = continuation - a - fee; // speculative paper estimate, not a calibrated probability
    if (edge > 0.005) return [BUY, clamp(0.5 + edge * 12, 0.5, 0.95), `net edge ${cents(edge)}/share (continuation ${cents(continuation)} vs ask ${cents(a)}+fee)`];
    if (edge < -0.02) return [AVOID, 0.5, `negative edge ${cents(edge)}/share after fees`];
    return [HOLD, 0.3, `edge ${cents(edge)}/share: thin`];
  });

// A speculative continuation mark; it is not an independent or calibrated outcome probability.
export function estimateContinuation(m, ctx) {
  const mid = m.mid(ctx.side);
  if (mid == null) return m.ask(ctx.side) || 0.5;
  let fair = mid;
  const fast = shortHorizonMove(m, ctx.now, 30000);
  if (fast && fast.consistency >= 0.65) {
    const sideMove = fast.move * (ctx.side === 0 ? 1 : -1);
    fair += clamp(sideMove * 0.5, -0.03, 0.03); // speculative continuation estimate, never a calibrated probability
  }
  return clamp(fair, 0.01, 0.99);
}

if (AGENTS.length !== 25) throw new Error(`expected 25 agents, got ${AGENTS.length}`);
export const AGENTS_BY_ID = Object.fromEntries(AGENTS.map((a) => [a.id, a]));

// ------------------------------------------------------------------ council

export function defaultRules() {
  return {
    min_buy_votes: 12,     // of 25
    max_avoid_votes: 0,
    min_edge: 0.03,        // an entry needs >= 3c/share of edge after fees (best on the recorded markets: 3–4c)
    min_arb_edge: 0.005,   // risk-free sets need >= 0.5c/share after fees
    max_resolve_hours: 1,  // focus on markets resolving within an hour
  };
}

export function runCouncil(m, ctx, rules) {
  ctx.rules = rules;
  const votes = AGENTS.map((a) => vote(a, m, ctx));
  const counts = { BUY: 0, HOLD: 0, AVOID: 0, ABSTAIN: 0 };
  for (const v of votes) counts[v.stance]++;
  const vetoedBy = votes.filter((v) => v.stance === AVOID && AGENTS_BY_ID[v.agent].veto).map((v) => v.agent);
  const buyStrengths = votes.filter((v) => v.stance === BUY).map((v) => v.strength);
  const conviction = buyStrengths.length ? 100 * buyStrengths.reduce((a, b) => a + b, 0) / buyStrengths.length : 0;
  const arb = ctx.event && ctx.event.arb && ctx.event.arb.edge >= rules.min_arb_edge;
  const close = ctx.close;
  const side = close ? close.sides[ctx.side] : null;
  const a = m.ask(ctx.side);
  // On a five-minute market the edge is the desk's: blended probability minus the stake's all-in price per share.
  const edge = close ? (side && side.edge != null ? side.edge : -1) : a != null ? estimateContinuation(m, ctx) - a - feePerShare(m, a) : -1;
  const said = (id) => votes.some((v) => v.agent === id && v.stance === BUY);
  // A risk-free set needs the safety vetoes clear and the edge real. A closing-window entry needs the settlement model
  // and the expected-value engine both for it, the edge after fees, the vote, and no safety veto.
  const isSignal = !vetoedBy.length && counts.AVOID <= rules.max_avoid_votes
    && (arb ? true : close
      ? counts.BUY >= rules.min_buy_votes && edge >= rules.min_edge && said("settlement_model") && said("expected_value")
      : counts.BUY >= rules.min_buy_votes && edge >= rules.min_edge && said("expected_value") && said("trend") && said("book_imbalance"));
  return {
    marketId: m.id, side: ctx.side, buy_votes: counts.BUY, hold_votes: counts.HOLD, avoid_votes: counts.AVOID,
    abstain_votes: counts.ABSTAIN, vetoed_by: vetoedBy, conviction: Math.round(conviction * 10) / 10,
    edge, arb: !!arb, is_signal: isSignal, votes,
    p: side ? side.p : null, cost: side ? side.cost : null,
  };
}

// Arbitrage math for a complete negRisk event: cost of one share of every outcome, after fees, vs the $1 payout.
export function arbForEvent(ev) {
  if (!ev || ev.augmented || !ev.members || ev.members.length < 2) return null;
  let cost = 0, fillable = true;
  for (const mm of ev.members) {
    const a = mm.ask(0);
    if (a == null || a <= 0) { fillable = false; break; }
    cost += a + feePerShare(mm, a);
  }
  if (!fillable) return null;
  return { cost, edge: 1 - cost, members: ev.members.length };
}

export function compareRank(a, b) {
  if (a.arb !== b.arb) return a.arb ? -1 : 1;
  return (b.edge - a.edge) || (b.conviction - a.conviction) || (b.buy_votes - a.buy_votes);
}

export function buildSignal(m, verdict, rules, now, ctx) {
  const side = verdict.side;
  const close = ctx.close || null;
  const a = m.ask(side);
  const reasons = verdict.votes.filter((v) => v.stance === BUY).sort((x, y) => y.strength - x.strength);
  const cautions = verdict.votes.filter((v) => v.stance === HOLD || v.stance === AVOID);
  return {
    id: `${m.id}:${side}:${Math.floor(now / 1000)}`,
    marketId: m.id, tokenId: m.tokenIds[side], side, eventId: m.eventId,
    question: m.question, eventTitle: m.eventTitle, outcome: m.outcomes[side], image: m.image,
    created: now,
    kind: verdict.arb ? "arbitrage" : "directional",
    arb: verdict.arb && ctx.event && ctx.event.arb ? {
      cost: ctx.event.arb.cost, edge: ctx.event.arb.edge, members: ctx.event.arb.members,
      memberIds: (ctx.event.members || []).map((x) => x.id),
      sets_payout: 1,
    } : null,
    headline: verdict.arb
      ? `RISK-FREE SET: ${m.eventTitle || m.question}`
      : close
        ? `BUY ${m.outcomes[side]} @ ${cents(a)} — ${close.label} closes in ${Math.max(0, close.secsToEnd).toFixed(0)} s, ${m.outcomes[side]} ${pct(side === 0 ? close.pUp : 1 - close.pUp)}`
        : `BUY ${m.outcomes[side]} @ ${cents(a)} — ${m.question}`,
    ask: a, mid: m.mid(side), bid: m.bid(side), continuation: close ? (side === 0 ? close.pUp : 1 - close.pUp) : estimateContinuation(m, ctx),
    model: close ? {
      coin: close.coin, secs_to_end: Math.round(close.secsToEnd * 10) / 10, strike: close.strike, spot: close.spot,
      p_model: close.pModel, p_market: close.pMarket, p_up: close.pUp, cost: close.sides[side] ? close.sides[side].cost : null,
    } : null,
    edge: verdict.edge, fee_per_share: feePerShare(m, a),
    agree: verdict.buy_votes, total_agents: AGENTS.length, conviction: verdict.conviction,
    end_ms: m.endMs,
    reasons: reasons.map((v) => ({ agent: AGENTS_BY_ID[v.agent].name, reason: v.reason, strength: v.strength })),
    cautions: cautions.map((v) => ({ agent: AGENTS_BY_ID[v.agent].name, stance: v.stance, reason: v.reason })),
    links: {
      polymarket: m.slug ? `https://polymarket.com/market/${m.slug}` : (m.eventId ? `https://polymarket.com/event/${m.eventId}` : "https://polymarket.com"),
    },
    outcome_result: null,
  };
}

// Score a directional signal once the market resolves: did that outcome win?
export function scoreSignal(sig, m) {
  if (!m || !m.resolved || m.winner == null) return null;
  const won = m.winner === sig.side;
  const payout = won ? 1 : 0;
  const net = payout - sig.ask - (sig.fee_per_share || 0); // per share, held to resolution
  return { status: won ? "win" : "loss", net_per_share: Math.round(net * 1000) / 1000, resolved_to: m.outcomes[m.winner] };
}
